#!/usr/bin/env python3
"""Verify immutable evidence and optionally render into a separate directory."""
import argparse
import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]


def csv_rows(path):
    with path.open(newline='') as f:return list(csv.DictReader(f))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=ROOT/'build/reproduced')
    p.add_argument('--render',action='store_true')
    a=p.parse_args();out=a.output.resolve()
    if out.exists():p.error('Choose a new output directory; existing evidence/results will not be overwritten.')
    out.mkdir(parents=True)
    stats=out/'verified-statistics.json'
    subprocess.run([sys.executable,str(ROOT/'verify_evidence.py'),'--root',str(ROOT),'--output',str(stats)],check=True)
    result={'statistics':'passed','accuracy_cells':98,'paired_intervals':126,'fp32_references':2,'rendered':False}
    if a.render:
        work=out/'manuscript';work.mkdir()
        for n in ('main.tex','author.tex','references.bib','main.bbl','build.sh','render_results.py'):
            shutil.copy2(ROOT/n,work/n)
        (work/'evidence').mkdir();shutil.copy2(stats,work/'evidence/verified-statistics.json')
        subprocess.run([sys.executable,str(work/'render_results.py')],cwd=work,check=True)
        for expected in sorted((ROOT/'tables').glob('*.tex')):
            if (work/'tables'/expected.name).read_text()!=expected.read_text():
                raise AssertionError('Regenerated table differs: '+expected.name)
        for name in ('all-accuracies.csv','all-target-contrasts.csv'):
            if csv_rows(work/'evidence'/name)!=csv_rows(ROOT/'evidence'/name):
                raise AssertionError('Regenerated result CSV differs: '+name)
        result.update(rendered=True,tables_match=True,result_csvs_match=True)
    (out/'reproduction-report.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Reproduced in',out)


if __name__=='__main__':main()
