param(
    [string]$Adb = "adb",
    [string]$Serial = "",
    [string]$SetupNotes = "not supplied",
    [switch]$SkipPush
)
$ErrorActionPreference = "Stop"
$bundle = $PSScriptRoot
$selector = @()
if ($Serial) { $selector = @("-s", $Serial) }
function Invoke-Adb {
    param([string[]]$Arguments)
    & $Adb @selector @Arguments
    if ($LASTEXITCODE -ne 0) { throw "ADB failed: $($Arguments -join ' ')" }
}
function Read-Adb {
    param([string[]]$Arguments)
    $output = & $Adb @selector @Arguments
    if ($LASTEXITCODE -ne 0) { throw "ADB failed: $($Arguments -join ' ')" }
    return ($output -join "`n")
}
function Write-Json {
    param($Value, [string]$Path)
    $text = ConvertTo-Json -InputObject $Value -Depth 16
    [IO.File]::WriteAllText($Path, $text + "`n", (New-Object Text.UTF8Encoding($false)))
}
$manifestPath = Join-Path $bundle "manifest.json"
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
$mode = $manifest.mode
if ($mode -notin @("Validate", "Final")) { throw "Unexpected package mode" }
foreach ($item in $manifest.files.PSObject.Properties) {
    $actual = (Get-FileHash -LiteralPath (Join-Path $bundle $item.Name) -Algorithm SHA256).Hash
    if ($actual -ne $item.Value) { throw "Checksum mismatch: $($item.Name)" }
}
$manifestHash = (Get-FileHash $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
$remote = "/data/local/tmp/" + $manifest.id
Invoke-Adb -Arguments @("get-state")
$soc = (Read-Adb -Arguments @("shell", "getprop", "ro.soc.model")).Trim()
$build = (Read-Adb -Arguments @("shell", "getprop", "ro.build.fingerprint")).Trim()
$deviceSerial = (Read-Adb -Arguments @("get-serialno")).Trim()
$phoneUtc = (Read-Adb -Arguments @("shell", "date", "-u", "+%Y-%m-%dT%H:%M:%SZ")).Trim()
$trial = (Get-Date -Format "yyyyMMdd-HHmmss") + "-" + ([Guid]::NewGuid().ToString("N").Substring(0,8))
$results = Join-Path $bundle ("returned-shared-" + $trial)
New-Item -ItemType Directory -Path $results | Out-Null
Copy-Item $manifestPath $results
$runRecord = @{mode=$mode; trial=$trial; manifest_sha256=$manifestHash; execution_identity_sha256=$manifest.execution_identity_sha256; device_build=$build; device_serial=$deviceSerial; soc=$soc; phone_utc_before=$phoneUtc; windows_started_utc=(Get-Date).ToUniversalTime().ToString("o"); setup_notes=$SetupNotes; thermal_policy="observation-only; not benchmark timings"}
Write-Json -Value $runRecord -Path (Join-Path $results "run.json")
if ($soc -ne "SM8850") { throw "Expected SM8850; identity saved in $results. Return it for review." }
if ($mode -eq "Final") {
    $audit = Get-Content (Join-Path $bundle "validation-audit.json") -Raw | ConvertFrom-Json
    if ($audit.status -ne "passed" -or $audit.mode -ne "Validate" -or $audit.execution_identity_sha256 -ne $manifest.execution_identity_sha256) {
        throw "This final package lacks a matching Linux validation audit. Return $results."
    }
    if ($audit.run.device_serial -ne $deviceSerial -or $audit.run.device_build -ne $build) {
        throw "Final acquisition requires the same validated handset/build. Identity saved in $results; return it for review."
    }
    Copy-Item (Join-Path $bundle "validation-audit.json") $results
}
if (-not $SkipPush) {
    Invoke-Adb -Arguments @("shell", "mkdir", "-p", $remote)
    foreach ($folder in @("bin", "lib", "dsp", "models", "inputs", "lists")) {
        Invoke-Adb -Arguments @("push", (Join-Path $bundle $folder), "$remote/")
    }
    foreach ($file in @("manifest.json", "payload-sha256.txt", "run_shared_device.sh")) {
        Invoke-Adb -Arguments @("push", (Join-Path $bundle $file), "$remote/")
    }
}
$line = Read-Adb -Arguments @("shell", "sha256sum", "$remote/payload-sha256.txt")
if (($line -split '\s+')[0] -ne $manifest.files.'payload-sha256.txt') { throw "Remote checksum-list mismatch" }
$null = Read-Adb -Arguments @("shell", "cd '$remote' && sha256sum -c payload-sha256.txt")
Invoke-Adb -Arguments @("shell", "chmod", "755", "$remote/bin/qnn-memory-runner", "$remote/bin/qnn-net-run")
$jobs = @($manifest.jobs)
Write-Json -Value $jobs -Path (Join-Path $results "jobs.json")
$failed = @()
$pullFailed = $false
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
Write-Host "$mode acquisition: $($jobs.Count) jobs. Temperatures are recorded; no 40 C starting gate. These are not benchmark timings."
try {
    foreach ($job in $jobs) {
        try {
            Write-Host "Running $($job.id)"
            Invoke-Adb -Arguments @("shell", "sh", "$remote/run_shared_device.sh", $trial, $job.id, $job.candidate, $job.mode, $job.chunk)
        } catch {
            $failed += @{job=$job.id; error="$_"}
            Write-Json -Value $failed -Path (Join-Path $results "failed-jobs.json")
            throw
        }
    }
} finally {
    & $Adb @selector pull "$remote/outputs/$trial" (Join-Path $results "outputs")
    $pullFailed = $LASTEXITCODE -ne 0
    $stopwatch.Stop()
    Write-Json -Value @{status="acquisition-ended"; failed_jobs=$failed.Count; pull_failed=$pullFailed; elapsed_seconds=$stopwatch.Elapsed.TotalSeconds; windows_finished_utc=(Get-Date).ToUniversalTime().ToString("o")} -Path (Join-Path $results "acquisition.json")
    Write-Host "Return this whole folder to Linux: $results"
    if ($pullFailed) { Write-Warning "Pull failed. Preserve terminal output and remote results." }
}
if ($pullFailed) { throw "Output pull failed; acquisition is incomplete." }
foreach ($job in $jobs) {
    $folder = Join-Path $results ("outputs/" + $job.id)
    if ((Get-Content (Join-Path $folder "exit-status.txt") -Raw).Trim() -ne "0") { throw "Nonzero job exit status" }
    $dlcDigest = (Get-Content (Join-Path $folder "model-sha256.txt") -Raw).Trim() -split '\s+'
    if ($dlcDigest[0] -ne $manifest.candidates.($job.candidate).dlc_sha256) { throw "Executed DLC differs from manifest" }
}
if ($mode -eq "Validate") {
    foreach ($candidate in $manifest.validation_candidates) {
        $reference = Join-Path $results "outputs/$candidate-reference/reference"
        $off = Join-Path $results "outputs/$candidate-validate-off"
        $basic = Join-Path $results "outputs/$candidate-validate-basic"
        $expected = New-Object IO.MemoryStream
        for ($i=0; $i -lt 10; $i++) {
            $files = @(Get-ChildItem -LiteralPath (Join-Path $reference "Result_$i") -Filter *.raw -Recurse)
            if ($files.Count -ne 1) { throw "Expected one reference output at index $i" }
            $bytes = [IO.File]::ReadAllBytes($files[0].FullName)
            if ($bytes.Length -ne 4000) { throw "Unexpected reference output length" }
            $expected.Write($bytes,0,$bytes.Length)
        }
        $hash = [Security.Cryptography.SHA256]::Create()
        $expectedHash = [BitConverter]::ToString($hash.ComputeHash($expected.ToArray())).Replace("-", "")
        $expected.Dispose(); $hash.Dispose()
        foreach ($folder in @($off,$basic)) {
            $meta = Get-Content (Join-Path $folder "complete.json") -Raw | ConvertFrom-Json
            if ($meta.calls -ne 10 -or $meta.warmup -ne 2 -or -not $meta.perf_api_accepted -or $meta.backend_build -ne "v2.45.41.260507231357") { throw "Unexpected runner metadata for $candidate" }
            if ((Get-FileHash (Join-Path $folder "logits.f32") -Algorithm SHA256).Hash -ne $expectedHash) { throw "Runner/reference output mismatch for $candidate" }
            $timings = @(Import-Csv (Join-Path $folder "timings.csv"))
            if ($timings.Count -ne 12 -or @($timings | Where-Object phase -eq "warmup").Count -ne 2) { throw "Warm-up recording failed" }
        }
        if (@(Import-Csv (Join-Path $off "events.csv")).Count -ne 0) { throw "Unexpected unprofiled events" }
        $events = @(Import-Csv (Join-Path $basic "events.csv"))
        for ($i=0; $i -lt 12; $i++) {
            if (@($events | Where-Object { [int]$_.call -eq $i -and [int]$_.type -eq 3012 -and [int]$_.unit -eq 1 }).Count -ne 1) { throw "Missing/ambiguous HTP event for $candidate call $i" }
        }
    }
    $record = @{status="passed-local-checks"; validation_trial=$trial; manifest_sha256=$manifestHash; execution_identity_sha256=$manifest.execution_identity_sha256; device_serial=$deviceSerial; device_build=$build; validation_directory=$results}
    Write-Json -Value $record -Path (Join-Path $results "validation-record.json")
    Write-Json -Value $record -Path (Join-Path $bundle ("validation-passed-" + $trial + ".json"))
    Write-Host "Local validation passed. Return $results for Linux audit. Final evaluation will use a separate matching package."
}
Write-Json -Value @{status="complete"; mode=$mode; jobs=$jobs.Count; manifest_sha256=$manifestHash} -Path (Join-Path $results "complete.json")
