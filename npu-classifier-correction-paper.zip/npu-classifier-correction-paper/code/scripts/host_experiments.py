"""Reproducible, forward-only host experiments. No device latency is inferred."""
import argparse
from collections import Counter
import gc
import json
from pathlib import Path
import time
import numpy as np
import onnx
import onnxruntime as ort
from aimet_onnx.quantsim import QuantizationSimModel
from aimet_onnx.utils import disable_quantizers
from pilot_common import ROOT, MODELS, rows, image_input, source_model, sha256, ort_options
from quantize_pilot import precision_map

RUN = ROOT / "results/host-20260927"

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=str) + "\n")

def cache_data():
    RUN.mkdir(parents=True, exist_ok=True)
    cache = ROOT / "data/host-cache"
    cache.mkdir(exist_ok=True)
    for split in ["calibration", "pilot_eval"]:
        records = rows(split)
        path = cache / f"{split}.npy"
        metadata = cache / f"{split}.json"
        expected = {"manifest_sha256": sha256(ROOT / "data" / f"{split}.csv"),
                    "preprocessing_code_sha256": sha256(ROOT / "scripts/pilot_common.py"), "count": len(records)}
        if path.exists() and metadata.exists() and json.loads(metadata.read_text()) == expected:
            continue
        data = np.lib.format.open_memmap(path, mode="w+", dtype=np.float32, shape=(len(records), 3, 224, 224))
        for i, row in enumerate(records):
            data[i] = image_input(row["path"])[0]
        data.flush()
        dump(metadata, expected)
    return np.load(cache / "calibration.npy", mmap_mode="r"), np.load(cache / "pilot_eval.npy", mmap_mode="r")

def predict(session, data):
    result = np.empty((len(data), 1000), dtype=np.float32)
    name = session.get_inputs()[0].name
    for i in range(len(data)):
        result[i] = session.run(None, {name: data[i:i+1]})[0][0]
    if not np.isfinite(result).all():
        raise RuntimeError("Non-finite logits")
    return result

def metrics(logits, reference=None):
    labels = np.array([int(r["label"]) for r in rows("pilot_eval")[:len(logits)]])
    predictions = logits.argmax(axis=1)
    result = {"n": len(labels), "top1_pct": float(100*np.mean(predictions == labels)),
              "selection_200_top1_pct": float(100*np.mean(predictions[:200] == labels[:200]))}
    if len(labels) > 200:
        result["remaining_800_top1_pct"] = float(100*np.mean(predictions[200:] == labels[200:]))
    if reference is not None:
        result["agreement_with_fp32_pct"] = float(100*np.mean(predictions == reference.argmax(axis=1)))
        result["logit_rmse"] = float(np.sqrt(np.mean((logits-reference)**2)))
        result["mean_cosine"] = float(np.mean(np.sum(logits*reference, axis=1) /
            np.maximum(np.linalg.norm(logits,axis=1)*np.linalg.norm(reference,axis=1),1e-12)))
    return result

def make_sim(model, activation_bits=8, scheme="min_max"):
    return QuantizationSimModel(onnx.load(source_model(model)), param_type="int8",
        activation_type=f"int{activation_bits}", quant_scheme=scheme, config_file="htp_v81",
        providers=["CPUExecutionProvider"], session_options_kwargs={"intra_op_num_threads":4,"inter_op_num_threads":1})

def calibrate(sim, data):
    sim.compute_encodings({"image_tensor": data[i:i+1]} for i in range(len(data)))

def export_result(sim, model, policy, cal_n, data, reference, extra=None):
    out = RUN / model / policy
    out.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    logits = predict(sim.session, data)
    np.save(out / "logits.npy", logits)
    sim.export(str(out), "model", encoding_version="1.0.0")
    onnx.checker.check_model(str(out / "model.onnx"))
    effective = precision_map(sim)
    report = {"model":model, "policy":policy, "calibration_samples":cal_n,
              "metrics":metrics(logits, reference), "quantizers":effective,
              "activation_counts_by_bits":dict(Counter(q["bits"] for q in effective.values() if q["enabled"] and q["kind"]=="activation")),
              "parameter_counts_by_bits":dict(Counter(q["bits"] for q in effective.values() if q["enabled"] and q["kind"]=="parameter")),
              "source_onnx_sha256":sha256(source_model(model)), "source_weights_sha256":sha256(source_model(model).with_suffix('.data')),
              "encoding_sha256":sha256(out/"model.encodings"), "evaluation_export_seconds":time.perf_counter()-start,
              "evidence":"CPU QuantSim; pilot dataset only; not device execution", **(extra or {})}
    dump(out/"result.json", report)
    print(model, policy, report["metrics"], flush=True)
    return report

def base_experiments():
    calibration, evaluation = cache_data()
    for model in MODELS:
        out = RUN / model
        out.mkdir(exist_ok=True)
        if not (out/"fp32.json").exists():
            session = ort.InferenceSession(str(source_model(model)), sess_options=ort_options(), providers=["CPUExecutionProvider"])
            reference = predict(session, evaluation)
            np.save(out/"fp32.npy", reference)
            dump(out/"fp32.json", {"model":model, "metrics":metrics(reference), "source_sha256":sha256(source_model(model))})
            print(model, "fp32", metrics(reference), flush=True)
            del session
        reference = np.load(out/"fp32.npy")
        for count in [100, 500]:
            for bits in [8,16]:
                policy=f"w8a{bits}-cal{count}"
                if (out/policy/"result.json").exists():
                    continue
                start=time.perf_counter()
                sim=make_sim(model,bits)
                calibrate(sim, calibration[:count])
                export_result(sim,model,policy,count,evaluation,reference,{"calibration_scheme":"min_max", "setup_calibration_seconds":time.perf_counter()-start})
                del sim
                gc.collect()
    diagnostics(calibration,evaluation)

def diagnostics(calibration,evaluation):
    model="mobilenet_v2"
    path=RUN/model/"diagnostics.json"
    if path.exists():
        return
    reference=np.load(RUN/model/"fp32.npy")
    sim=make_sim(model)
    calibrate(sim,calibration[:500])
    report={"scope":"Inference ablations reuse the cal500 encodings; not deployable policies or re-calibrated baselines."}
    for name,disabled in [
        ("all_quantizers_off",list(sim.qc_quantize_op_dict)),
        ("weights_only",list(sim.activation_names)),
        ("activations_only",list(sim.param_names)),
        ("normalization_quantizers_off",[x for x in ["image_tensor","sub","div"] if x in sim.qc_quantize_op_dict])]:
        with disable_quantizers(sim,disabled):
            logits=predict(sim.session,evaluation)
        report[name]={"disabled":disabled,"metrics":metrics(logits,reference),"max_abs_vs_fp32":float(np.max(np.abs(logits-reference)))}
        print("diagnostic",name,report[name]["metrics"],flush=True)
    dump(path,report)

if __name__=="__main__":
    base_experiments()
