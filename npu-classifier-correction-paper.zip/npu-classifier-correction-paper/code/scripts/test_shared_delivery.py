"""Synthetic unit fixtures only: gate, output decoder and paired uncertainty."""
import csv
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import shared_delivery as delivery
from shared_common import dump, sha256, ROOT
from analyze_recalibration_return import memory_outputs
from summarize_shared_study import paired_ci


class DeliveryTests(unittest.TestCase):
    def test_paired_class_intervals_do_not_count_duplicates_as_new_classes(self):
        labels=np.repeat(np.arange(20),2);d=np.linspace(-1,1,40)
        first=paired_ci(d,labels,repetitions=1000)
        repeated=paired_ci(np.repeat(d,3),np.repeat(labels,3),repetitions=1000)
        np.testing.assert_allclose(first,repeated,atol=1e-12)
        np.testing.assert_allclose(paired_ci(np.ones(40),labels,repetitions=1000),[100,100])

    def test_validation_requires_matching_inventory_and_unchanged_evidence(self):
        with tempfile.TemporaryDirectory(prefix='shared-unit-') as tmp:
            root=Path(tmp);ret=root/'returned';ret.mkdir();(ret/'evidence.txt').write_text('synthetic unit fixture')
            report={'status':'passed','mode':'Validate','trial':'val-1','execution_identity_sha256':'matching',
                    'candidates':{str(i):{} for i in range(28)},
                    'analysis_code_sha256':sha256(ROOT/'scripts/analyze_shared_return.py'),
                    'returned_directory':str(ret),'returned_file_sha256':{'evidence.txt':sha256(ret/'evidence.txt')}}
            path=root/'device/val-1/report.json';dump(path,report)
            with patch.object(delivery,'EXP',root),patch.object(delivery,'verify_seal',return_value={'execution_identity_sha256':'matching'}):
                self.assertEqual(delivery.validation_gate(path)['trial'],'val-1')
                report['execution_identity_sha256']='other-model';dump(path,report)
                with self.assertRaises(ValueError):delivery.validation_gate(path)
                report['execution_identity_sha256']='matching';dump(path,report)
                (ret/'evidence.txt').write_text('changed fixture')
                with self.assertRaises(ValueError):delivery.validation_gate(path)

    def test_missing_htp_event_or_truncated_tensor_rejected(self):
        with tempfile.TemporaryDirectory(prefix='shared-unit-') as tmp:
            folder=Path(tmp)
            dump(folder/'complete.json',{'calls':10,'warmup':2,'perf_api_accepted':True,'backend_build':'v2.45.41.260507231357'})
            np.zeros((10,1000),dtype=np.float32).tofile(folder/'logits.f32')
            (folder/'timings.csv').write_text('phase\n'+'warmup\n'*2+'measured\n'*10)
            events='call,type,unit\n'+''.join(f'{i},3012,1\n' for i in range(12))
            (folder/'events.csv').write_text(events)
            self.assertEqual(memory_outputs(folder,10,2,'basic').shape,(10,1000))
            (folder/'events.csv').write_text('call,type,unit\n')
            with self.assertRaises(ValueError):memory_outputs(folder,10,2,'basic')
            (folder/'events.csv').write_text(events)
            np.zeros((9,1000),dtype=np.float32).tofile(folder/'logits.f32')
            with self.assertRaises(ValueError):memory_outputs(folder,10,2,'basic')


if __name__=='__main__':unittest.main()
