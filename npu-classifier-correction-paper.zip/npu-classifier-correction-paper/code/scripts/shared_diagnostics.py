"""Explanatory feature-space diagnostics; not native accuracy or new theory."""
import json
import numpy as np
from shared_common import *


def main():
    report={'scope':'descriptive source/target feature diagnostics on adaptation and development only; not method selection',
            'identity':'For nondegenerate channels, shared slope = mean(v_c*a_c) / (mean(v_c) + Var(source_means)/(1+ridge)). Standard least-squares algebra; not a novel theorem.',
            'models':{}}
    for model in MODELS:
        if not complete(EXP/model/'fits/result.json'):raise ValueError('Fits incomplete')
        x=np.asarray([np.load(EXP/model/s/'calibration-features.npy') for s in SOURCES],dtype=np.float64)
        teacher=np.load(EXP/model/'fp32/calibration-features.npy').astype(np.float64)
        variances=x.var(1);within=variances.mean(0);between=x.mean(1).var(0)
        ridge=protocol()['fit']['ridge'];denom=within+between/(1+ridge)
        source_slopes=np.asarray([np.load(EXP/model/'fits'/(s+'.npz'))['a'] for s in SOURCES])
        shared=np.load(EXP/model/'fits/shared.npz');average=np.load(EXP/model/'fits/average.npz')
        valid=(variances>1e-12).all(0)&(denom>1e-12)
        explained=np.mean(variances*source_slopes,axis=0)[valid]/denom[valid]
        values={'nondegenerate_channels':int(valid.sum()),
                'shared_slope_algebra_max_abs_float32':float(np.max(np.abs(explained-shared['a'][valid]))) if valid.any() else None,
                'between_over_total_feature_variance_median':float(np.median(between/np.maximum(within+between,1e-12))),
                'shared_minus_average_slope_rms':float(np.sqrt(np.mean((shared['a']-average['a'])**2))),
                'shared_minus_average_intercept_rms':float(np.sqrt(np.mean((shared['b']-average['b'])**2))),
                'targets':[]}
        for split in ('calibration','selection'):
            expected=np.load(EXP/model/'fp32'/(split+'-features.npy')).astype(np.float64)
            for target in TARGETS:
                features=np.load(EXP/model/target/(split+'-features.npy')).astype(np.float64)
                for arm,source in [('single','cal-a'),('average','average'),('shared','shared'),('refit',target)]:
                    params=np.load(EXP/model/'fits'/(source+'.npz'))
                    corrected=features*params['a']+params['b']
                    values['targets'].append({'target':target,'split':split,'arm':arm,
                        'baseline_feature_mse':float(np.mean((features-expected)**2)),
                        'corrected_feature_mse':float(np.mean((corrected-expected)**2)),
                        'meaning':'float feature alignment before folding/re-encoding; not NPU accuracy'})
        report['models'][model]=values
    dump(EXP/'feature-diagnostics.json',report);print(EXP/'feature-diagnostics.json')


if __name__=='__main__':main()
