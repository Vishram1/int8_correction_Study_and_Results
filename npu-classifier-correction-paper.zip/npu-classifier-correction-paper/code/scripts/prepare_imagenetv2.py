"""Verify ImageNetV2 MatchedFrequency and freeze calibration/selection/final manifests."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tarfile

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_SHA = 'f0c37fdf925916b19ea1323cd9a2208cdb6959ba2c32eef2a7fc393835c9ca7c'
ARCHIVE_BYTES = 1264079360
SEED = 'imagenetv2-20260928-v1'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive', type=Path, default=ROOT/'downloads/imagenetv2-matched-frequency.tar.gz.part')
    p.add_argument('--experiment', type=Path, default=ROOT/'experiments/imagenetv2-20260928')
    args = p.parse_args()
    out = args.experiment/'data'
    if (out/'dataset.json').exists():
        saved = json.loads((out/'dataset.json').read_text())
        for name, checksum in saved['manifest_sha256'].items():
            if sha(out/name) != checksum: raise RuntimeError('Frozen manifest changed: '+name)
        print('Existing frozen manifests verified; no files changed.'); return
    if args.archive.stat().st_size != ARCHIVE_BYTES or sha(args.archive) != ARCHIVE_SHA:
        raise RuntimeError('ImageNetV2 archive size/SHA256 mismatch')
    out.mkdir(parents=True, exist_ok=True)
    images = ROOT/'data/imagenetv2-matched-frequency'
    images.mkdir(parents=True, exist_ok=True)
    records = []
    with tarfile.open(args.archive) as archive:
        members = archive.getmembers()
        regular = [m for m in members if m.isfile()]
        if len(regular) != 10000 or any(not(m.isfile() or m.isdir()) for m in members):
            raise RuntimeError('Unexpected archive members')
        for i, member in enumerate(regular):
            parts = PurePosixPath(member.name).parts
            if len(parts) != 3 or parts[0] != 'imagenetv2-matched-frequency-format-val' or not parts[1].isdigit() or '..' in parts:
                raise RuntimeError('Unexpected image path: '+member.name)
            label = int(parts[1])
            if not 0 <= label < 1000: raise RuntimeError('Invalid numeric label')
            target = images/parts[1]/parts[2]
            target.parent.mkdir(exist_ok=True)
            with archive.extractfile(member) as source, target.open('wb') as destination:
                shutil.copyfileobj(source, destination)
            with Image.open(target) as image:
                image.load()
                rgb = image.convert('RGB')
                pixel_hash = hashlib.sha256(str(rgb.size).encode()+b'\0'+rgb.tobytes()).hexdigest()
            records.append({'path':str(target.relative_to(ROOT)), 'label':label, 'sha256':sha(target), 'pixel_sha256':pixel_hash})
            if (i+1)%2000==0: print(f'Decoded and hashed {i+1}/10000 images', flush=True)
    if Counter(r['label'] for r in records) != Counter({i:10 for i in range(1000)}):
        raise RuntimeError('Expected ten images per numeric class 0..999')
    duplicates = defaultdict(list)
    for row in records: duplicates[row['pixel_sha256']].append(row)
    groups = [v for v in duplicates.values() if len(v)>1]
    reserved = {r['path'] for group in groups for r in group}
    split = {'calibration':[], 'selection':[], 'final':[]}
    for label in range(1000):
        members = [r for r in records if r['label']==label]
        unique = [r for r in members if r['path'] not in reserved]
        unique.sort(key=lambda r: hashlib.sha256((SEED+'/'+r['path']).encode()).hexdigest())
        if len(unique)<3: raise RuntimeError('Duplicate groups prevent the declared split for class '+str(label))
        split['calibration'].append(unique[0])
        split['selection'].extend(unique[1:3])
        held = [r for r in members if r['path'] not in {x['path'] for x in unique[:3]}]
        held.sort(key=lambda r: hashlib.sha256((SEED+'/'+r['path']).encode()).hexdigest())
        split['final'].extend(held)
    # Interleave class blocks; prefixes used by sensitivity still cover many classes.
    for name, count in [('calibration',1),('selection',2),('final',7)]:
        rows = split[name]
        split[name] = [rows[c*count+i] for i in range(count) for c in range(1000)]
        with (out/(name+'.csv')).open('w', newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(split[name])
    for left,right in [('calibration','selection'),('calibration','final'),('selection','final')]:
        for key in ['sha256','pixel_sha256']:
            if {r[key] for r in split[left]} & {r[key] for r in split[right]}: raise RuntimeError('Cross-split duplicate')
    metadata = {
        'dataset':'ImageNetV2 MatchedFrequency', 'frozen_date':'2026-09-28', 'seed':SEED,
        'archive_sha256':ARCHIVE_SHA, 'archive_bytes':ARCHIVE_BYTES,
        'url':'https://huggingface.co/datasets/vaishaal/ImageNetV2/resolve/d626240be2538720e83103a0e1178d24aca8b12c/imagenetv2-matched-frequency.tar.gz',
        'counts':{k:len(v) for k,v in split.items()}, 'label_rule':'Integer directory name is the original 0..999 model class index',
        'all_images_decoded':True, 'cross_split_duplicate_content':0,
        'duplicate_pixel_groups':groups, 'duplicate_policy':'Reserve all decoded-pixel duplicate groups together in final before selecting singleton development images; retain counts and report duplicates if any',
        'manifest_sha256':{n+'.csv':sha(out/(n+'.csv')) for n in split},
        'final_access':'No model evaluation performed by this script; final is excluded from calibration/selection',
        'terms':'Public ungated dataset download; images retain their source usage terms',
    }
    (out/'dataset.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps({'counts':metadata['counts'],'duplicate_groups':len(groups),'manifest_sha256':metadata['manifest_sha256']},indent=2))


if __name__=='__main__':main()
