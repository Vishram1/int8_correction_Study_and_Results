"""Prepare all completed host policies for Android and audit their DLC IR."""
import argparse
from collections import Counter
import json
from pathlib import Path
import subprocess
import time
import numpy as np
from host_experiments import RUN, cache_data, dump
from pilot_common import ROOT, sha256

DTYPES={0x0408:'uint8_fixed',0x0416:'uint16_fixed',0x0308:'int8_fixed',0x0316:'int16_fixed',0x0332:'int32_fixed',0x0232:'float32',0x0216:'float16'}
DTYPE_BITS={0x0408:8,0x0416:16,0x0308:8,0x0316:16,0x0332:32,0x0232:32,0x0216:16}

def command(args,log):
    with log.open('w') as f:
        subprocess.run(['bash',str(ROOT/'scripts/qairt.sh'),*map(str,args)],stdout=f,stderr=subprocess.STDOUT,check=True)

def audit(out):
    graph=json.loads((out/'graph.json').read_text())['graph']
    tensors=graph['tensors'];nodes=graph['nodes']
    dynamic={k:v for k,v in tensors.items() if v['type']!=4}
    conversions=[]
    weights=[]
    for name,node in nodes.items():
        if node['type']=='Convert':
            conversions.append({'name':name,'inputs':node['input_names'],'outputs':node['output_names'],
                'input_tensor_elements':int(np.prod(tensors[node['input_names'][0]]['dims']))})
        if node['type'] in ['Conv2d','DepthWiseConv2d','FullyConnected']:
            t=tensors[node['input_names'][1]]
            qp=t.get('quant_params',{})
            axis=qp.get('axis_scale_offset',qp.get('bw_axis_scale_offset',{}))
            bias=tensors[node['input_names'][2]] if len(node['input_names'])>2 else None
            weights.append({'node':name,'tensor':node['input_names'][1],
                'dtype':DTYPES.get(t['data_type'],hex(t['data_type'])),
                'quantization_axis':axis.get('axis'),'scale_count':axis.get('num_scale_offsets',1),
                'encoding_overridden':qp.get('is_overridden'),
                'bias_dtype':DTYPES.get(bias['data_type'],hex(bias['data_type'])) if bias else None})
    assert weights and all(w['dtype']=='int8_fixed' for w in weights),weights
    assert tensors['image_tensor']['dims']==[1,224,224,3]
    report={'stage':'DLC IR, before HTP finalization/execution',
        'activation_dtype_counts':dict(Counter(DTYPES.get(t['data_type'],hex(t['data_type'])) for t in dynamic.values())),
        'activation_tensor_storage_sum_bytes':sum(int(np.prod(t['dims']))*(DTYPE_BITS[t['data_type']]//8) for t in dynamic.values()),
        'storage_note':'Sum of logical tensor sizes; not peak live memory or measured device memory',
        'convert_nodes':conversions,'convert_count':len(conversions),
        'operators':dict(Counter(n['type'] for n in nodes.values())),
        'compute_weights':weights,'input':tensors['image_tensor'],'output':tensors['class_logits'],
        'dlc_bytes':(out/'quantized.dlc').stat().st_size,'dlc_sha256':sha256(out/'quantized.dlc')}
    dump(out/'dlc-audit.json',report)
    return report

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cpu-check',action='store_true')
    args=parser.parse_args()
    cal,ev=cache_data()
    raw=ROOT/'data/host-nhwc'
    raw.mkdir(exist_ok=True)
    for split,data in [('calibration',cal),('eval',ev[:10])]:
        for i in range(len(data)):
            path=raw/f'{split}_{i:04d}.raw'
            if not path.exists(): np.ascontiguousarray(data[i].transpose(1,2,0)).tofile(path)
    statuses=[]
    for meta in sorted(RUN.glob('*/*/result.json')):
        out=meta.parent
        r=json.loads(meta.read_text())
        # cal100 is for calibration sensitivity; ship cal500 and mixed policies.
        if r['calibration_samples']!=500: continue
        status={'model':r['model'],'policy':r['policy']}
        try:
            t0=time.perf_counter()
            if not (out/'dlc-audit.json').exists():
                command(['qairt-converter','--input_network',out/'model.onnx','--quantization_overrides',out/'model.encodings',
                         '--source_model_input_layout','image_tensor','NCHW','--desired_input_layout','image_tensor','NHWC',
                         '--output_path',out/'with-encodings.dlc'],out/'convert.log')
                inputs=out/'calibration-nhwc.txt'
                inputs.write_text(''.join(f'image_tensor:={raw}/calibration_{i:04d}.raw\n' for i in range(500)))
                command(['qairt-quantizer','--input_dlc',out/'with-encodings.dlc','--output_dlc',out/'quantized.dlc',
                         '--input_list',inputs,'--weights_bitwidth','8','--act_bitwidth','16' if r['policy'].startswith('w8a16') else '8',
                         '--bias_bitwidth','32','--use_per_channel_quantization'],out/'quantize.log')
                command(['qairt-dlc-to-json','--input_dlc',out/'quantized.dlc','--output_json',out/'graph.json'],out/'dlc-json.log')
                command(['qairt-dlc-info','--input_dlc',out/'quantized.dlc','--save',out/'dlc-info.csv'],out/'dlc-info.txt')
                audit(out)
                dump(out/'conversion-cost.json',{'seconds':time.perf_counter()-t0,'not_device_compilation':True})
            status['status']='converted_and_audited'
            if args.cpu_check and not (out/'cpu-check.json').exists():
                cpu_dir=out/'qnn-cpu'
                inputs=out/'cpu-inputs.txt'
                inputs.write_text(''.join(f'image_tensor:={raw}/eval_{i:04d}.raw\n' for i in range(10)))
                sdk=ROOT/'tools/qairt/2.45.41.260507/lib/x86_64-linux-clang'
                try:
                    command(['qnn-net-run','--model',sdk/'libQnnModelDlc.so','--dlc_path',out/'quantized.dlc',
                             '--backend',sdk/'libQnnCpu.so','--input_list',inputs,'--output_dir',cpu_dir],out/'cpu-run.log')
                    sim=np.load(out/'logits.npy')[:10]
                    values=[]
                    for i in range(10):
                        files=list((cpu_dir/f'Result_{i}').rglob('*.raw'))
                        assert len(files)==1,files
                        value=np.fromfile(files[0],dtype=np.float32)
                        assert len(value)==1000 and np.isfinite(value).all()
                        values.append(value)
                    values=np.array(values)
                    np.save(out/'qnn-cpu-logits.npy',values)
                    dump(out/'cpu-check.json',{'status':'executed','samples':10,'agreement_with_sim_pct':float(100*np.mean(values.argmax(1)==sim.argmax(1))),
                        'rmse_vs_sim':float(np.sqrt(np.mean((values-sim)**2))),'note':'QNN CPU correctness diagnostic; not NPU accuracy or latency'})
                except Exception as e:
                    dump(out/'cpu-check.json',{'status':'failed','error':str(e),'note':'CPU backend check failure does not establish NPU support or failure; inspect cpu-run.log'})
        except Exception as e:
            status.update(status='failed',error=str(e))
        statuses.append(status)
        print(status,flush=True)
    dump(RUN/'conversion-status.json',statuses)

if __name__=='__main__': main()
