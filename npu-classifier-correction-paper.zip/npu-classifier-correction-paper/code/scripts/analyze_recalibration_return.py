"""Audit exact pilot jobs and score returned NPU outputs without final data."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np

from recalibration_common import ROOT, EXP, sha256, dump, metrics, comparison, read_rows


def memory_outputs(folder, calls, warmup, profile):
    meta=json.loads((folder/'complete.json').read_text())
    if meta['calls']!=calls or meta['warmup']!=warmup or not meta['perf_api_accepted'] or meta['backend_build']!='v2.45.41.260507231357':
        raise ValueError('Unexpected runner/backend metadata: '+str(folder))
    values=np.fromfile(folder/'logits.f32',dtype=np.float32)
    if values.size!=calls*1000 or not np.isfinite(values).all():
        raise ValueError('Incomplete or invalid outputs: '+str(folder))
    with (folder/'timings.csv').open() as f:timings=list(csv.DictReader(f))
    if len(timings)!=calls+warmup or sum(x['phase']=='warmup' for x in timings)!=warmup:
        raise ValueError('Missing call or warmup records')
    with (folder/'events.csv').open() as f:events=list(csv.DictReader(f))
    if profile=='basic':
        for i in range(calls+warmup):
            matches=[e for e in events if int(e['call'])==i and int(e['type'])==3012 and int(e['unit'])==1]
            if len(matches)!=1:raise ValueError('Missing/ambiguous HTP event')
    elif events:
        raise ValueError('Unprofiled job unexpectedly contains profile events')
    return values.reshape(calls,1000)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('returned',type=Path);args=parser.parse_args()
    returned=args.returned.resolve();bundle=ROOT/'exports/npu-recalibration-20261006-v2'
    if sha256(returned/'manifest.json')!=sha256(bundle/'manifest.json'):
        raise ValueError('Returned manifest differs from the sealed package')
    m=json.loads((bundle/'manifest.json').read_text());run=json.loads((returned/'run.json').read_text())
    if run['manifest_sha256']!=sha256(bundle/'manifest.json') or run['soc']!='SM8850':
        raise ValueError('Bundle/device identity mismatch')
    if run['mode'] not in ('Validate','Development'):
        raise ValueError('Unexpected acquisition mode')
    if (returned/'failed-jobs.json').exists() and json.loads((returned/'failed-jobs.json').read_text()):
        raise ValueError('Acquisition contains failed jobs; preserve and diagnose before scoring')
    jobs=json.loads((returned/'jobs.json').read_text())
    if run['mode']=='Validate':
        expected=[{'id':cid+'-'+kind,'candidate':cid,'mode':kind,'chunk':'0','session':0}
                  for cid in m['validation_candidates'] for kind in ('reference','validate-off','validate-basic')]
    else:
        expected=m['development_jobs']
        link=json.loads((returned/'validation-link.json').read_text())
        for key in ('manifest_sha256','device_build','device_serial'):
            if link[key]!=run[key]:raise ValueError('Prerequisite validation identity mismatch')
        previous=EXP/'device'/link['validation_trial']/'report.json'
        if not previous.exists() or json.loads(previous.read_text()).get('status')!='passed':
            raise ValueError('Return and analyze the linked validation acquisition first')
    if jobs!=expected:raise ValueError('Acquisition jobs/order differ from the sealed plan')
    expected_names={j['id'] for j in jobs}
    actual_names={p.name for p in (returned/'outputs').iterdir() if p.is_dir()}
    if expected_names!=actual_names:raise ValueError('Missing/extra job directories')
    for job in jobs:
        folder=returned/'outputs'/job['id']
        if (folder/'exit-status.txt').read_text().strip()!='0':raise ValueError('Job failed: '+job['id'])
        for name in ('candidate','mode','chunk'):
            if (folder/(name+'.txt')).read_text().strip()!=str(job[name]):raise ValueError('Job identity mismatch')
        properties=dict(line.split('=',1) for line in (folder/'device-properties.txt').read_text().splitlines() if '=' in line)
        if properties['ro.soc.model']!=run['soc'] or properties['ro.build.fingerprint']!=run['device_build']:
            raise ValueError('Device/build changed within acquisition')
    report={'status':'passed','mode':run['mode'],'trial':run['trial'],'jobs':len(jobs),'run':run,
            'manifest_sha256':sha256(bundle/'manifest.json'),'returned_directory':str(returned),
            'scope':'Development accuracy/validation; no final images or controlled latency estimates',
            'analysis_code_sha256':sha256(Path(__file__)),'candidates':{}}
    dest=EXP/'device'/run['trial'];dest.mkdir(parents=True,exist_ok=True)
    for cid,info in m['candidates'].items():
        host=np.load(bundle/'host-reference'/(cid+'.npy'))
        if sha256(bundle/'models'/(cid+'.dlc'))!=info['dlc_sha256']:
            raise ValueError('Local sealed model changed')
        if run['mode']=='Validate':
            ref=returned/'outputs'/(cid+'-reference')/'reference';rows=[]
            for i in range(10):
                files=list((ref/f'Result_{i}').rglob('*.raw'))
                if len(files)!=1:raise ValueError('Expected exactly one reference output')
                row=np.fromfile(files[0],dtype=np.float32)
                if row.shape!=(1000,) or not np.isfinite(row).all():raise ValueError('Invalid reference tensor')
                rows.append(row)
            values=np.asarray(rows)
            for kind,profile in [('validate-off','off'),('validate-basic','basic')]:
                actual=memory_outputs(returned/'outputs'/(cid+'-'+kind),10,2,profile)
                if not np.array_equal(actual,values):raise ValueError('Runner/reference/profile outputs differ')
            report['candidates'][cid]={'runner_reference_bitwise_equal':True,'htp_profile_calls_verified':12,
                                      'host_comparison':comparison(values,host[:10])}
        else:
            candidate_jobs=sorted([j for j in jobs if j['candidate']==cid],key=lambda j:int(j['chunk']))
            if [int(j['chunk']) for j in candidate_jobs]!=list(range(20)):raise ValueError('Accuracy chunk coverage mismatch')
            values=np.concatenate([memory_outputs(returned/'outputs'/j['id'],100,0,'off') for j in candidate_jobs])
            report['candidates'][cid]={'metadata':info,'metrics':metrics(values),'host_comparison':comparison(values,host)}
        np.save(dest/(cid+'.npy'),values)
    if run['mode']=='Development':
        matrix=[]
        for target in ('cal-a','cal-b'):
            baseline=report['candidates'][target+'__baseline']['metrics']['top1_pct']
            for method in ('affine','output-bias'):
                matched=report['candidates'][target+'__'+method+'__'+target]['metrics']['top1_pct']
                for source in ('cal-a','cal-b'):
                    score=report['candidates'][target+'__'+method+'__'+source]['metrics']['top1_pct']
                    matrix.append({'target':target,'source':source,'method':method,'top1_pct':score,
                                   'change_vs_target_baseline_pp':score-baseline,'target_refitted_minus_reused_pp':matched-score})
        report['transfer_matrix']=matrix
    report['returned_file_sha256']={str(p.relative_to(returned)):sha256(p) for p in sorted(returned.rglob('*')) if p.is_file()}
    dump(dest/'report.json',report)
    print(json.dumps({k:report[k] for k in ('status','mode','jobs','candidates')},indent=2))
    print('Saved',dest/'report.json')


if __name__=='__main__':main()
