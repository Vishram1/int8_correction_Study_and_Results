#!/usr/bin/env bash
# Isolate legacy SDK dependencies from the AIMET environment.
set -euo pipefail
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export QAIRT_SDK_ROOT="$task_root/tools/qairt/2.45.41.260507"
export QNN_SDK_ROOT="$QAIRT_SDK_ROOT"
export PATH="$task_root/.venv-qairt/bin:$QAIRT_SDK_ROOT/bin/x86_64-linux-clang:$PATH"
export PYTHONPATH="$QAIRT_SDK_ROOT/lib/python"
export LD_LIBRARY_PATH="$task_root/tools/host-libs/usr/lib/x86_64-linux-gnu:$task_root/tools/host-libs/usr/lib/llvm-14/lib:$QAIRT_SDK_ROOT/lib/x86_64-linux-clang${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export OMP_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=4
if [[ $# -eq 0 ]]; then
    echo 'Usage: bash research/scripts/qairt.sh <SDK-command> [arguments...]' >&2
    exit 2
fi
exec "$@"
