"""Seal seeds and analysis before new calibration inference; verify reused caches."""
import json
import platform
import shutil
from datetime import datetime, timezone
import importlib.metadata
import numpy as np
from shared_common import *
import recalibration_common as prior


def main():
    if (EXP/'protocol.json').exists():
        protocol()
    else:
        original = prior.protocol()
        sources = original['sources']
        for model, info in sources.items():
            for rel, digest in info['files'].items():
                if sha256(ROOT/rel) != digest:
                    raise ValueError('Original source changed: ' + rel)
        for split, digest in original['data']['cache_sha256'].items():
            if sha256(OLD/'cache'/(split+'.npy')) != digest:
                raise ValueError('Original input cache changed')
        reused = {}
        for model in MODELS:
            for variant in ('fp32', 'cal-a', 'cal-b'):
                path = PREVIOUS/model/variant/'cache-result.json'
                if not prior.complete(path):
                    raise ValueError('Original cache incomplete')
                reused[str(path.relative_to(ROOT))] = sha256(path)
        variants = dict(original['calibration']['variants'])
        for name, seed in [('source-c', 2026101401)] + [(t, 2026101410+i) for i,t in enumerate(TARGETS, 1)]:
            indices = sorted(np.random.default_rng(seed).choice(1000, 500, replace=False).tolist())
            variants[name] = {'seed': seed, 'indices': indices, 'n': 500}
        overlaps = {a: {b: len(set(v['indices']) & set(w['indices'])) for b,w in variants.items()}
                    for a,v in variants.items()}
        for name, digest in original['data']['manifest_sha256'].items():
            if sha256(OLD/'data'/name) != digest:
                raise ValueError('Dataset manifest changed')
        p = {
            'id': EXP.name, 'schema': 1, 'frozen_utc': datetime.now(timezone.utc).isoformat(),
            'question': 'Does a shared classifier correction retain accuracy on previously unseen INT8 recalibrations better than ordinary reuse or parameter averaging?',
            'models': list(MODELS), 'sources': sources, 'source_calibrations': list(SOURCES),
            'target_calibrations': list(TARGETS), 'primary_single_source': 'cal-a',
            'native_targets': ['target-1', 'target-2'], 'arms': list(ARMS),
            'calibration': {**original['calibration'], 'variants': variants, 'overlap_matrix': overlaps},
            'data': {**original['data'], 'final': '7000 images; one evaluation after artifact freeze and native validation',
                     'previously_seen': 'A/B and all development results were examined before this extension; target seeds and final evaluation are prospective.'},
            'fit': {'ridge': 0.01, 'images': 1000, 'teacher': 'frozen FP32 classifier input on the same adaptation images',
                    'single': original['fit']['objective'],
                    'shared_objective': 'mean_c mean_i (a*h[c,i]+b-h_fp[i])^2 + 0.01*mean_c Var_i(h[c,i])*(a-1)^2, independently per channel',
                    'shared_solution': 'a=(pooled_cov+0.01*mean_within_variance)/(pooled_variance+0.01*mean_within_variance); b=mean_teacher-a*pooled_mean',
                    'degenerate': 'if pooled variance <=1e-12: a=1, b=mean_teacher-pooled_mean',
                    'average': 'arithmetic mean of three single-source a vectors and three b vectors, float64 accumulation then float32 storage',
                    'target_refit': 'same single-source affine formula with target features; privileged target-aware comparator, not an upper bound',
                    'bias_refit': 'mean(teacher final logits - target raw classifier logits) on the adaptation images',
                    'access': 'single/average/shared use only sources A/B/C; target features only for target-refit/bias and mandatory target head re-encoding',
                    'no_training': 'closed form; frozen backbone; no labels in fitting; no hyperparameter search'},
            'export': original['export'],
            'analysis': {'primary_contrasts': ['shared-minus-single', 'shared-minus-refit'],
                         'secondary_contrasts': ['shared-minus-average', 'single-minus-refit', 'shared-minus-head-reencode', 'shared-minus-baseline', 'shared-minus-bias-refit'],
                         'unit': 'percentage points top1; NumPy argmax first index on ties',
                         'report': 'every target/arm; equal-target mean and worst observed contrast, per architecture and backend separately',
                         'intervals': '10000 paired class-cluster bootstrap resamples; identical class draws for all targets/arms; 95% pointwise percentile intervals conditional on the observed target calibrations',
                         'bootstrap_seed': 2026101499,
                         'calibration_variation': 'show all five host/two native target effects and their range; do not count images as calibration replicates; no population-wide guarantee',
                         'loss_budget_pp': 0.5,
                         'loss_budget_rationale': 'prospective working engineering budget: 35/7000 additional mistakes per target. No user-specified application requirement exists; this is a descriptive study criterion, not a validated deployment tolerance.',
                         'noninferiority_claim': False,
                         'costs': 'record forward extraction, fit, head re-encoding/export and compilation separately; shared and average use the same three-source budget; target-refit extraction is incremental beyond required 500 target calibration examples; no latency/energy claim',
                         'failures': 'retain every technical failure and unfavorable result; do not replace target draws, arms or ridge based on accuracy'},
            'validation': {'reference_calls': 10, 'runner_calls': 10, 'warmups': 2,
                           'require_bitwise_equivalence': True, 'htp_event_type': 3012,
                           'thermal_policy': 'observe only, Android thermal management left enabled; accuracy acquisition is not a timing benchmark',
                           'same_unit_build_for_validation_and_final': True, 'soc': 'SM8850',
                           'final_gate': 'sealed artifact matrix + successful Linux-audited native validation on the selected unit'},
            'environment': {'python': platform.python_version(), 'numpy': np.__version__,
                            **{n:importlib.metadata.version(n) for n in ('onnx','onnxruntime','aimet-onnx')},
                            'qairt': '2.45.41.260507', 'forward_threads': 4},
            'prior_protocol_sha256': sha256(PREVIOUS/'protocol.json'), 'reused_cache_records': reused,
            'limitations': ['Five overlapping draws from one calibration pool; same images in all adaptation fits.',
                           'Three sources include previously studied A/B; only targets and final images are prospective.',
                           'Shared fitting, affine compensation and averaging are established; no algorithmic novelty claim.',
                           'Native evidence restricted to two prespecified targets per architecture.'],
        }
        dump(EXP/'protocol.json', p)
        (EXP/'protocol.sha256').write_text(sha256(EXP/'protocol.json')+'  protocol.json\n')
        for split in ('calibration','selection','final'):
            shutil.copy2(OLD/'data'/(split+'.csv'), EXP/(split+'.csv'))
    p = protocol()
    for model in MODELS:
        for variant in ('fp32','cal-a','cal-b'):
            dest = EXP/model/variant
            if complete(dest/'cache-result.json'):
                continue
            source = PREVIOUS/model/variant
            record = source/'cache-result.json'
            if sha256(record) != p['reused_cache_records'][str(record.relative_to(ROOT))] or not prior.complete(record):
                raise ValueError('Cached source provenance changed')
            result = json.loads(record.read_text()); files = []
            dest.mkdir(parents=True,exist_ok=True)
            for rel in result['artifacts']:
                src = PREVIOUS/rel; dst = dest/src.name
                shutil.copy2(src,dst); files.append(dst)
            save_result(dest/'cache-result.json', {k:v for k,v in result.items() if k not in ('protocol_sha256','artifacts')}
                        | {'reused_from':str(record.relative_to(ROOT)), 'original_record_sha256':sha256(record),
                           'cached_cost_is_historical_not_new_measurement':True}, files)
    print('Protocol sealed; original teacher/A/B caches verified and copied:', EXP, flush=True)


if __name__ == '__main__':
    main()
