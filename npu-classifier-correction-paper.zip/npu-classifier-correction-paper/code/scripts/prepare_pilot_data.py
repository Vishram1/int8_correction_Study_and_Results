"""Create deterministic, class-balanced pilot manifests and QNN raw inputs."""
import csv
import json
from pilot_common import ROOT, CLASSES, sha256, image_input

def main():
    manifests = {}
    for split, source, per_class in [("calibration", "train", 50), ("pilot_eval", "val", 100)]:
        selected = []
        for synset, label in CLASSES.items():
            files = sorted((ROOT / "data/imagenette2-320" / source / synset).glob("*.JPEG"))
            # Hash sorting is stable across machines and independent of filesystem order.
            import hashlib
            files.sort(key=lambda p: hashlib.sha256(("20260926/" + p.name).encode()).hexdigest())
            for p in files[:per_class]:
                selected.append({"path": str(p.relative_to(ROOT)), "label": label,
                                 "synset": synset, "sha256": sha256(p)})
        if len(selected) != per_class * len(CLASSES):
            raise RuntimeError(f"Incomplete {split} data")
        # Interleave classes so a short prefix remains balanced.
        selected = [selected[c * per_class + i] for i in range(per_class) for c in range(len(CLASSES))]
        manifests[split] = selected
        with (ROOT / "data" / f"{split}.csv").open("w") as f:
            writer = csv.DictWriter(f, fieldnames=["path", "label", "synset", "sha256"])
            writer.writeheader()
            writer.writerows(selected)
    a = {r["sha256"] for r in manifests["calibration"]}
    b = {r["sha256"] for r in manifests["pilot_eval"]}
    if a & b:
        raise RuntimeError("Cross-split duplicate image content; revise manifests")
    out = ROOT / "data/raw"
    out.mkdir(exist_ok=True)
    # Converter calibration files use absolute host paths. Native CLI uses float NCHW here;
    # inspect converter I/O metadata before device deployment (it may change layout).
    lines = []
    for i, row in enumerate(manifests["calibration"]):
        path = out / f"calibration_{i:04d}.raw"
        image_input(row["path"]).tofile(path)
        lines.append(f"image_tensor:={path}\n")
    (ROOT / "data/calibration_input_list.txt").write_text("".join(lines))
    (ROOT / "results/pilot-data.json").write_text(json.dumps({
        "seed": "20260926", "dataset": "imagenette2-320", "calibration": 500,
        "pilot_eval": 1000, "cross_split_duplicate_sha256": 0,
        "class_mapping": CLASSES, "metric": "1000-way top-1 on ten selected classes",
        "preprocessing": "RGB; bilinear resize short side 256; center crop 224; float32 NCHW [0,1]",
        "limitation": "Pilot only. ImageNette's resplit may contain original ImageNet training images; do not use as unbiased final ImageNet evaluation.",
        "manifests": {s: sha256(ROOT / "data" / f"{s}.csv") for s in manifests}
    }, indent=2) + "\n")
    print("Prepared 500 calibration and 1000 disjoint pilot evaluation examples; raw calibration inputs ready.")

if __name__ == "__main__":
    main()
