"""Audit the exact extension return and bind successful validation to artifacts."""
import argparse
import csv
import json
from pathlib import Path
import re
import numpy as np
from shared_common import *
from shared_delivery import verify_seal, validation_gate
from analyze_recalibration_return import memory_outputs


def audit_return(returned):
    returned=Path(returned).resolve();freeze=verify_seal()
    m=json.loads((returned/'manifest.json').read_text());run=json.loads((returned/'run.json').read_text())
    if m['id'] not in ('npu-shared-validate-20261014-v1','npu-shared-final-20261014-v1'):
        raise ValueError('Unregistered bundle')
    bundle=ROOT/'exports'/m['id']
    if sha256(returned/'manifest.json')!=sha256(bundle/'manifest.json'):
        raise ValueError('Returned manifest differs from original package')
    if run['manifest_sha256']!=sha256(bundle/'manifest.json') or run['soc']!='SM8850':
        raise ValueError('Bundle/device mismatch')
    if run['mode']!=m['mode'] or run['execution_identity_sha256']!=freeze['execution_identity_sha256']:
        raise ValueError('Execution identity/mode mismatch')
    if not re.fullmatch(r'[A-Za-z0-9_-]+',run['trial']):raise ValueError('Invalid trial name')
    done=json.loads((returned/'complete.json').read_text())
    if done!={'status':'complete','mode':m['mode'],'jobs':len(m['jobs']),'manifest_sha256':run['manifest_sha256']}:
        raise ValueError('Acquisition did not complete')
    acquisition=json.loads((returned/'acquisition.json').read_text())
    if acquisition['failed_jobs'] or acquisition['pull_failed']:raise ValueError('Acquisition/pull failed')
    if (returned/'failed-jobs.json').exists() and json.loads((returned/'failed-jobs.json').read_text()):
        raise ValueError('Returned failed jobs')
    jobs=json.loads((returned/'jobs.json').read_text())
    if jobs!=m['jobs']:raise ValueError('Job plan/order changed')
    if {p.name for p in (returned/'outputs').iterdir() if p.is_dir()}!={j['id'] for j in jobs}:
        raise ValueError('Missing/extra output directories')
    if m['mode']=='Final':
        audit=validation_gate(EXP/'device'/m['validation_trial']/'report.json')
        if sha256(returned/'validation-audit.json')!=sha256(EXP/'device'/m['validation_trial']/'report.json'):
            raise ValueError('Validation link changed')
        for key in ('device_serial','device_build'):
            if run[key]!=audit['run'][key]:raise ValueError('Final handset/build differs from validation')
    else:
        local=json.loads((returned/'validation-record.json').read_text())
        if local['status']!='passed-local-checks' or local['validation_trial']!=run['trial']:
            raise ValueError('Missing local validation record')
        for key in ('manifest_sha256','execution_identity_sha256','device_serial','device_build'):
            if local[key]!=run[key]:raise ValueError('Local validation record mismatch')
    thermal=[]
    for job in jobs:
        folder=returned/'outputs'/job['id']
        if (folder/'exit-status.txt').read_text().strip()!='0':raise ValueError('Nonzero job exit')
        for key in ('candidate','mode','chunk'):
            if (folder/(key+'.txt')).read_text().strip()!=job[key]:raise ValueError('Job identity mismatch')
        digest=(folder/'model-sha256.txt').read_text().split()[0]
        if digest!=m['candidates'][job['candidate']]['dlc_sha256']:raise ValueError('Executed model changed')
        props=dict(line.split('=',1) for line in (folder/'device-properties.txt').read_text().splitlines() if '=' in line)
        if props.get('ro.soc.model')!=run['soc'] or props.get('ro.build.fingerprint')!=run['device_build']:
            raise ValueError('Device/build changed during acquisition')
        for phase in ('before','after'):
            raw=(folder/f'thermal-{phase}.txt').read_text()
            current=re.search(r'Current temperatures from HAL:\s*(.*?)Current cooling devices from HAL:',raw,re.S)
            values=[float(x) for x in re.findall(r'Temperature\{mValue=([0-9.]+), mType=9, mName=nsp[0-9]+,',current.group(1))] if current else []
            thermal.append({'job':job['id'],'phase':phase,'max_nsp_c':max(values) if values else None})
    dest=EXP/'device'/run['trial'];dest.mkdir(parents=True,exist_ok=True)
    report={'status':'passed','mode':m['mode'],'trial':run['trial'],'run':run,'jobs':len(jobs),
            'manifest_sha256':sha256(bundle/'manifest.json'),'execution_identity_sha256':freeze['execution_identity_sha256'],
            'analysis_code_sha256':sha256(Path(__file__)),'returned_directory':str(returned),'candidates':{},
            'scope':'accuracy/runner validation only; no controlled latency or energy claim','thermal_snapshots':thermal}
    for cid,info in m['candidates'].items():
        if sha256(bundle/'models'/(cid+'.dlc'))!=info['dlc_sha256']:raise ValueError('Sealed DLC changed')
        if m['mode']=='Validate':
            ref=returned/'outputs'/(cid+'-reference')/'reference';rows=[]
            for i in range(10):
                files=list((ref/f'Result_{i}').rglob('*.raw'))
                if len(files)!=1:raise ValueError('Expected exactly one reference output')
                row=np.fromfile(files[0],dtype=np.float32)
                if row.shape!=(1000,) or not np.isfinite(row).all():raise ValueError('Invalid reference output')
                rows.append(row)
            values=np.asarray(rows)
            for kind,profile in [('validate-off','off'),('validate-basic','basic')]:
                actual=memory_outputs(returned/'outputs'/(cid+'-'+kind),10,2,profile)
                if not np.array_equal(actual,values):raise ValueError('Runner/profile/reference differ')
            report['candidates'][cid]={'metadata':info,'runner_reference_bitwise_equal':True,
                                      'htp_profile_calls_verified':12,
                                      'host_comparison':comparison(values,np.load(bundle/'host-reference'/(cid+'.npy')))}
        else:
            candidate_jobs=sorted((j for j in jobs if j['candidate']==cid),key=lambda j:int(j['chunk']))
            if [int(j['chunk']) for j in candidate_jobs]!=list(range(70)):raise ValueError('Final chunk coverage mismatch')
            values=np.concatenate([memory_outputs(returned/'outputs'/j['id'],100,0,'off') for j in candidate_jobs])
            with (EXP/'final.csv').open() as f:labels=np.array([int(r['label']) for r in csv.DictReader(f)])
            report['candidates'][cid]={'metadata':info,'top1_pct':float(100*np.mean(values.argmax(1)==labels)),
                                      'n':7000,'tie_count':int(((values==values.max(1)[:,None]).sum(1)>1).sum())}
        np.save(dest/(cid+'.npy'),values)
    report['returned_file_sha256']={str(p.relative_to(returned)):sha256(p) for p in sorted(returned.rglob('*')) if p.is_file()}
    report['arrays_sha256']={p.name:sha256(p) for p in sorted(dest.glob('*.npy'))}
    path=dest/'report.json'
    if path.exists() and json.loads(path.read_text())!=report:raise ValueError('Do not overwrite a different completed audit')
    dump(path,report)
    print(json.dumps({'status':'passed','mode':m['mode'],'jobs':len(jobs),'candidates':len(report['candidates']),
                      'report':str(path),'htp_calls':sum(c.get('htp_profile_calls_verified',0) for c in report['candidates'].values())},indent=2))
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('returned',type=Path);a=p.parse_args();audit_return(a.returned)
