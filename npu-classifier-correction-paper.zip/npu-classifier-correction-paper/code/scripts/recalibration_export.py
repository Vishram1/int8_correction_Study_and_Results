"""Fold fitted corrections, preserve upstream grids and prepare QAIRT artifacts."""
import argparse
import copy
import gc
import json
import shutil
import time

import numpy as np
import onnx
from aimet_onnx.quantsim import QuantizationSimModel, load_encodings_to_sim
from aimet_onnx.qc_quantize_op import OpMode
from aimet_onnx.utils import OrtInferenceSession
from convert_experiments import command, audit
from recalibration_common import (ROOT, EXP, OLD, MODELS, protocol, inputs, dump, sha256,
    source_model, save_result, complete, comparison, metrics, fold_affine)
from recalibration_pilot import classifier, announce, run_logits


def sliced_head(sim, head, directory):
    """Cut at the actual QDQ classifier input while sharing live AIMET quantizers."""
    original = sim.model.model
    gemm = next(n for n in original.graph.node if n.name == head['node'])
    feature = gemm.input[0]
    output = sim.session.get_outputs()[0].name
    producers = {t: n for n in original.graph.node for t in n.output}
    needed, visited = set(), set()

    def visit(tensor):
        if tensor == feature or tensor in visited:
            return
        visited.add(tensor)
        if tensor not in producers:
            return
        node = producers[tensor]; needed.add(node.name)
        for name in node.input:
            visit(name)

    visit(output)
    graph = copy.deepcopy(original)
    del graph.graph.node[:]
    graph.graph.node.extend(copy.deepcopy(n) for n in original.graph.node if n.name in needed)
    del graph.graph.initializer[:]
    graph.graph.initializer.extend(copy.deepcopy(t) for t in original.graph.initializer if t.name in visited)
    del graph.graph.input[:]
    graph.graph.input.append(onnx.helper.make_tensor_value_info(feature, onnx.TensorProto.FLOAT, [1, head['dimension']]))
    del graph.graph.output[:]
    graph.graph.output.append(onnx.helper.make_tensor_value_info(output, onnx.TensorProto.FLOAT, [1, 1000]))
    del graph.graph.value_info[:]
    directory.mkdir(parents=True, exist_ok=True)
    session = OrtInferenceSession(graph, sim.providers, session_options=sim._ort_session_options, path=str(directory))
    return session


def append_controls():
    """Additional no-learning control, recorded before the first fit/export result."""
    path = EXP/'export-controls.json'
    if path.exists():
        if sha256(path) != (EXP/'export-controls.sha256').read_text().split()[0]:
            raise ValueError('Export-control declaration changed')
        return
    from datetime import datetime, timezone
    dump(path, {'declared_utc':datetime.now(timezone.utc).isoformat(), 'protocol_sha256':sha256(EXP/'protocol.json'),
                'control':'head-reencode', 'learned_parameters':0,
                'purpose':'Distinguish learned correction effects from rematerializing the effective classifier and recalibrating its output.',
                'procedure':'Use a=1,b=0 on the cached effective target head, then run exactly the corrected-head re-encoding path.',
                'identity':'Also retain an identity export using the original tensors/encodings without recalibration.',
                'changes_to_primary_fit_recipe':False})
    (EXP/'export-controls.sha256').write_text(sha256(path)+'  export-controls.json\n')


def candidate(model, target, treatment, source=None):
    cid = target+'__'+treatment+('__'+source if source else '')
    out = EXP/model/'deploy'/cid
    if complete(out/'host-result.json'):
        return out
    if not complete(EXP/model/target/'cache-result.json'):
        raise ValueError('Target cache incomplete')
    start=time.perf_counter();head,_,_=classifier(model)
    base=EXP/model/target; enc=json.loads((base/'model.encodings').read_text())
    graph=onnx.load(source_model(model))
    if treatment not in ('baseline','identity'):
        effective=np.load(base/'head.npz');w,b=effective['weight'],effective['bias']
        if treatment=='affine':
            correction=np.load(EXP/model/'fits'/(source+'.npz'))
            w,b=fold_affine(w,b,correction['a'],correction['b'])
        elif treatment=='output-bias':
            b=b+np.load(EXP/model/'fits'/(source+'.npz'))['output_bias']
        elif treatment!='head-reencode':
            raise ValueError('Unknown correction')
        for tensor in graph.graph.initializer:
            if tensor.name==head['weight']:
                tensor.CopyFrom(onnx.numpy_helper.from_array(np.asarray(w,np.float32),tensor.name))
            elif tensor.name==head['bias']:
                tensor.CopyFrom(onnx.numpy_helper.from_array(np.asarray(b,np.float32),tensor.name))
    sim=QuantizationSimModel(graph,param_type='int8',activation_type='int8',quant_scheme='tf_enhanced',
        config_file='htp_v81',providers=['CPUExecutionProvider'],session_options_kwargs={'intra_op_num_threads':4,'inter_op_num_threads':1})
    load_encodings_to_sim(sim,enc,strict=True)
    changed={head['weight'],head['bias'],head['logits']}
    head_session=sliced_head(sim,head,out/'head-runtime')
    if treatment not in ('baseline','identity'):
        for name,q in sim.qc_quantize_op_dict.items():
            if name not in changed:
                q.freeze_encodings()
        cal_features=np.load(base/'calibration-features.npy')
        indices=protocol()['calibration']['variants'][target]['indices']

        def calibrate_head(_):
            # AIMET's global context sets activations to updateStats, including frozen
            # activations. Keep frozen ops in QDQ mode; only head quantizers may learn.
            for q in sim.qc_quantize_op_dict.values():
                if q.is_encoding_frozen():
                    q.op_mode=OpMode.quantizeDequantize
            input_name=head_session.get_inputs()[0].name
            for i in indices:
                head_session.run(None,{input_name:cal_features[i:i+1]})

        sim.compute_encodings(calibrate_head)
    out.mkdir(parents=True,exist_ok=True)
    sim.export(str(out),'model',encoding_version='1.0.0')
    updated=json.loads((out/'model.encodings').read_text())
    changes=[]
    for kind in ('activation_encodings','param_encodings'):
        old={e['name']:e for e in enc[kind]};new={e['name']:e for e in updated[kind]}
        for name in old.keys()|new.keys():
            if old.get(name)!=new.get(name):
                changes.append({'kind':kind,'name':name})
                if name not in changed:
                    raise ValueError('Upstream encoding changed: '+name)
    h=np.load(base/'selection-features.npy')
    logits=run_logits(head_session,h)
    # Verify the sliced-cache route against actual full-graph execution on 32 inputs.
    full=run_logits(sim.session,inputs('selection')[:32])
    match=comparison(logits[:32],full)
    if match['max_abs']>1e-5 or match['prediction_disagreements']:
        dump(out/'slice-failure.json',match)
        raise ValueError('Cached head does not reproduce full graph')
    np.save(out/'logits.npy',logits)
    baseline=np.load(base/'selection-logits.npy')
    identity=comparison(logits,baseline) if treatment in ('baseline','identity') else None
    if identity and (identity['max_abs']>1e-5 or identity['prediction_disagreements']):
        raise ValueError('Identity export changed baseline')
    # Backbone tensor contents, graph nodes and edges must remain unchanged.
    original=onnx.load(source_model(model))
    model_out=onnx.load(out/'model.onnx')
    original_tensors={t.name:onnx.numpy_helper.to_array(t) for t in original.graph.initializer}
    final_tensors={t.name:onnx.numpy_helper.to_array(t) for t in model_out.graph.initializer}
    tensor_changes=[n for n in original_tensors if not np.array_equal(original_tensors[n],final_tensors[n])]
    if set(tensor_changes)-{head['weight'],head['bias']}:
        raise ValueError('A backbone tensor was modified')
    save_result(out/'host-result.json',{'status':'complete','id':cid,'model':model,'target':target,'source':source,
        'treatment':treatment,'metrics':metrics(logits),'baseline_metrics':metrics(baseline),
        'encoding_changes':changes,'upstream_encodings_unchanged':True,'parameter_changes':tensor_changes,
        'head_slice_full_graph_check':match,'identity_check':identity,'seconds':time.perf_counter()-start,
        'export_script_sha256':sha256(ROOT/'scripts/recalibration_export.py'),
        'control_declaration_sha256':sha256(EXP/'export-controls.json'),
        'evidence':'AIMET simulation with exported classifier encodings, not native NPU inference'},
        [out/'model.onnx',out/'model.encodings',out/'logits.npy'])
    announce(model+' '+cid+' exported host top1='+str(metrics(logits)['top1_pct']))
    del head_session,sim;gc.collect()
    return out


def convert(out):
    if complete(out/'conversion-result.json'):
        return
    start=time.perf_counter();r=json.loads((out/'host-result.json').read_text());target=r['target']
    indices=protocol()['calibration']['variants'][target]['indices']
    # Reuse verified NHWC calibration input files from the completed original study.
    raw=OLD/'raw-calibration'
    if any(not (raw/f'{i:04d}.raw').is_file() for i in indices):
        raise ValueError('Required existing raw calibration input missing')
    data=inputs('calibration')
    for i in indices:
        expected=np.ascontiguousarray(data[i].transpose(1,2,0))
        actual=np.fromfile(raw/f'{i:04d}.raw',dtype=np.float32).reshape(224,224,3)
        if not np.array_equal(expected,actual):
            raise ValueError('NHWC calibration input mismatch')
    input_list=out/'calibration-nhwc.txt'
    input_list.write_text(''.join(f'image_tensor:={raw}/{i:04d}.raw\n' for i in indices))
    command(['qairt-converter','--input_network',out/'model.onnx','--quantization_overrides',out/'model.encodings',
        '--source_model_input_layout','image_tensor','NCHW','--desired_input_layout','image_tensor','NHWC',
        '--output_path',out/'with-encodings.dlc'],out/'convert.log')
    command(['qairt-quantizer','--input_dlc',out/'with-encodings.dlc','--output_dlc',out/'quantized.dlc',
        '--input_list',input_list,'--weights_bitwidth','8','--act_bitwidth','8','--bias_bitwidth','32',
        '--use_per_channel_quantization'],out/'quantize.log')
    command(['qairt-dlc-to-json','--input_dlc',out/'quantized.dlc','--output_json',out/'graph.json'],out/'dlc-json.log')
    report=audit(out)
    save_result(out/'conversion-result.json',{'status':'complete','seconds':time.perf_counter()-start,
        'sdk':'2.45.41.260507','audit':report,'host_result_sha256':sha256(out/'host-result.json'),
        'export_script_sha256':sha256(ROOT/'scripts/recalibration_export.py'),
        'evidence':'DLC IR conversion; HTP execution pending'},
        [out/'quantized.dlc',out/'graph.json',out/'calibration-nhwc.txt',out/'dlc-audit.json'])
    announce(r['id']+' QAIRT converted')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',choices=MODELS,default='mobilenet_v2')
    parser.add_argument('--convert',action='store_true')
    parser.add_argument('--declare-controls-only',action='store_true')
    args=parser.parse_args();protocol();append_controls()
    if args.declare_controls_only:
        return
    if not complete(EXP/args.model/'fits/result.json'):
        raise ValueError('Complete the two-calibration fits before export')
    for target in ('cal-a','cal-b'):
        for treatment,source in [('baseline',None),('identity',None),('head-reencode',None),
                                 ('affine','cal-a'),('affine','cal-b'),('output-bias','cal-a'),('output-bias','cal-b')]:
            out=candidate(args.model,target,treatment,source)
            if args.convert and treatment!='identity':
                convert(out)


if __name__=='__main__':
    main()
