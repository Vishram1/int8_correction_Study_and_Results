"""AIMET PTQ feasibility exports, not AMP search or an optimized mixed policy."""
import argparse
from collections import Counter
import gc
import json
import time
import numpy as np
import onnx
from aimet_onnx.quantsim import QuantizationSimModel
from aimet_onnx.amp.quantizer_groups import find_quantizer_group
from aimet_onnx.common.defs import QuantizationDataType
from pilot_common import ROOT, MODELS, source_model, rows, image_input, sha256

def precision_map(sim):
    params = set(sim.param_names)
    return {name: {"kind": "parameter" if name in params else "activation",
                   "enabled": bool(q.enabled), "bits": q.bitwidth,
                   "dtype": str(q.data_type), "symmetric": bool(q.use_symmetric_encodings)}
            for name, q in sorted(sim.qc_quantize_op_dict.items())}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", choices=MODELS, default="mobilenet_v2")
    p.add_argument("--calibration-samples", type=int, default=100)
    p.add_argument("--eval-samples", type=int, default=100)
    args = p.parse_args()
    calibration = rows("calibration")[:args.calibration_samples]
    evaluation = rows("pilot_eval")[:args.eval_samples]
    if not calibration or not evaluation:
        raise ValueError("Need calibration and evaluation examples")
    out_root = ROOT / "results/pilot-artifacts" / args.model
    out_root.mkdir(parents=True, exist_ok=True)
    reports = {}
    for policy in ["w8a8", "w8a16", "mixed"]:
        out = out_root / policy
        out.mkdir(exist_ok=True)
        start = time.perf_counter()
        model = onnx.load(source_model(args.model))
        order = {name: i for i, node in enumerate(model.graph.node) for name in node.output}
        sim = QuantizationSimModel(
            model, param_type="int8", activation_type="int16" if policy == "w8a16" else "int8",
            config_file="htp_v81", providers=["CPUExecutionProvider"],
            session_options_kwargs={"intra_op_num_threads": 4, "inter_op_num_threads": 1},
        )
        requested = []
        if policy == "mixed":
            quantizers, groups = find_quantizer_group(sim)
            eligible = [g for g in groups if g.activation_quantizers and g.parameter_quantizers
                        and "image_tensor" not in g.activation_quantizers]
            eligible.sort(key=lambda g: (min(order.get(n, -1) for n in g.activation_quantizers),
                                         g.activation_quantizers))
            if not eligible:
                raise RuntimeError("No eligible mixed-precision quantizer group")
            group = eligible[len(eligible) // 2]
            group.set_quantizers_to_candidate(quantizers, ((16, QuantizationDataType.int), (8, QuantizationDataType.int)))
            requested = list(group.activation_quantizers)
        before = precision_map(sim)
        # This is the same constraint pass called by the pinned AIMET ONNX AMP
        # implementation; private/version-specific API deliberately recorded here.
        sim._apply_exception_rules()
        effective = precision_map(sim)
        sim.compute_encodings({"image_tensor": image_input(r["path"])} for r in calibration)
        predictions = []
        for i, row in enumerate(evaluation):
            logits = sim.session.run(None, {"image_tensor": image_input(row["path"])})[0]
            if logits.shape != (1, 1000) or not np.isfinite(logits).all():
                raise RuntimeError("Invalid QuantSim output")
            predictions.append({"path": row["path"], "label": int(row["label"]), "prediction": int(logits.argmax())})
            if i < 10:
                logits.astype(np.float32).tofile(out / f"reference_logits_{i:02d}.raw")
        sim.export(str(out), "model", encoding_version="1.0.0")
        onnx.checker.check_model(str(out / "model.onnx"))
        correct = sum(r["label"] == r["prediction"] for r in predictions)
        report = {
            "policy": policy, "source_onnx_sha256": sha256(source_model(args.model)),
            "purpose": "CPU quantization simulation and export feasibility only; not compiled NPU evidence",
            "htp_config": "htp_v81 (device still to be verified)", "requested_a16_tensors": requested,
            "before_constraint_pass": before, "effective_sim_quantizers": effective,
            "activation_counts_by_bits": dict(Counter(q["bits"] for q in effective.values() if q["enabled"] and q["kind"] == "activation")),
            "parameter_counts_by_bits": dict(Counter(q["bits"] for q in effective.values() if q["enabled"] and q["kind"] == "parameter")),
            "calibration_samples": len(calibration), "eval_samples": len(evaluation),
            "correct": correct, "pilot_top1_pct": 100 * correct / len(evaluation),
            "predictions": predictions, "preparation_seconds": time.perf_counter() - start,
            "encoding_sha256": sha256(out / "model.encodings"),
            "export_format": "Unquantized ONNX plus separate AIMET 1.0.0 encodings; must compile together",
        }
        (out / "policy.json").write_text(json.dumps(report, indent=2) + "\n")
        reports[policy] = {k: report[k] for k in ["policy", "activation_counts_by_bits", "parameter_counts_by_bits", "calibration_samples", "eval_samples", "correct", "pilot_top1_pct", "preparation_seconds"]}
        print(f"{policy}: simulated {correct}/{len(evaluation)}; exported ONNX + encodings", flush=True)
        del sim
        gc.collect()
    (ROOT / "results" / f"{args.model}-quantization-smoke.json").write_text(json.dumps(reports, indent=2) + "\n")

if __name__ == "__main__":
    main()
