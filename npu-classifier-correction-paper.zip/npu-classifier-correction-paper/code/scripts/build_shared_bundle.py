"""Build validation-only handoff, or gated final package after its Linux audit."""
import argparse
import json
from pathlib import Path
import shutil
import zipfile
import numpy as np
from shared_common import *
from shared_delivery import RUNTIME, runtime_files, seal, verify_seal, validation_gate, final_inputs, SCRIPT_NAMES


def build(mode, audit_path=None):
    freeze=seal() if mode=='Validate' else verify_seal()
    audit=validation_gate(audit_path) if mode=='Final' else None
    bundle=ROOT/'exports'/('npu-shared-'+mode.lower()+'-20261014-v1')
    if bundle.exists() or bundle.with_suffix('.zip').exists():
        raise ValueError('Preserve existing package; refuse overwrite: '+str(bundle))
    bundle.mkdir(parents=True)
    for name in ('models','lists','inputs','source','host-reference','audits'):(bundle/name).mkdir()
    for src in runtime_files():
        dest=bundle/src.relative_to(RUNTIME);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
    for name in ('Run-SharedStudy.ps1','run_shared_device.sh'):shutil.copy2(ROOT/'scripts'/name,bundle/name)
    for name in SCRIPT_NAMES:shutil.copy2(ROOT/'scripts'/name,bundle/'source'/name)
    for name in ('protocol.json','protocol.sha256','artifact-freeze.json','artifact-freeze.sha256',
                 'execution-identity.json','native-structure.json'):shutil.copy2(EXP/name,bundle/name)
    if audit:shutil.copy2(audit_path,bundle/'validation-audit.json')
    if mode=='Validate':
        previous=json.loads((RUNTIME/'manifest.json').read_text())
        for i in range(10):
            rel=f'inputs/selection-{i:04d}.raw';src=RUNTIME/rel
            if sha256(src)!=previous['files'][rel]:raise ValueError('Validation input changed')
            shutil.copy2(src,bundle/rel)
        (bundle/'lists/timing.txt').write_text(''.join(f'inputs/selection-{i:04d}.raw\n' for i in range(10)))
        (bundle/'lists/timing-qnn.txt').write_text(''.join(f'image_tensor:=inputs/selection-{i:04d}.raw\n' for i in range(10)))
    else:
        data=final_inputs(audit_path)
        for i in range(7000):np.ascontiguousarray(data[i].transpose(1,2,0)).tofile(bundle/'inputs'/f'final-{i:04d}.raw')
        for c in range(70):(bundle/'lists'/f'final-{c}.txt').write_text(''.join(f'inputs/final-{i:04d}.raw\n' for i in range(c*100,(c+1)*100)))
    candidates={}
    for model,target,arm,out in matrix(native=True):
        cid=model+'__'+target+'__'+arm
        shutil.copy2(out/'quantized.dlc',bundle/'models'/(cid+'.dlc'))
        if mode=='Validate':np.save(bundle/'host-reference'/(cid+'.npy'),np.load(out/'logits.npy')[:10])
        for name in ('host-result.json','dlc-audit.json'):shutil.copy2(out/name,bundle/'audits'/(cid+'-'+name))
        candidates[cid]={'model':model,'target':target,'arm':arm,'dlc_sha256':sha256(out/'quantized.dlc'),
                         'directory':str(out.relative_to(ROOT))}
    jobs=[]
    if mode=='Validate':
        jobs=[{'id':c+'-'+k,'candidate':c,'mode':k,'chunk':'0','session':0}
              for c in candidates for k in ('reference','validate-off','validate-basic')]
    else:
        rng=np.random.default_rng(2026101498)
        for chunk in range(70):
            order=list(candidates);rng.shuffle(order)
            jobs.extend({'id':c+f'-final-{chunk:02d}','candidate':c,'mode':'accuracy','chunk':str(chunk),'session':0} for c in order)
    payload=[bundle/'run_shared_device.sh']
    for name in ('bin','lib','dsp','models','inputs','lists'):payload.extend(p for p in (bundle/name).rglob('*') if p.is_file())
    (bundle/'payload-sha256.txt').write_text(''.join(sha256(p)+'  '+str(p.relative_to(bundle))+'\n' for p in sorted(payload)))
    (bundle/'README.md').write_text(f'''# Shared-correction {mode.lower()} acquisition

28 fixed artifacts: MobileNetV2 and ResNet18, two target calibrations each, seven arms.
This package has {len(jobs)} jobs. Mode is fixed by the manifest: {mode}.

1. Extract the ZIP on Windows. Open PowerShell in the directory with this README.
2. Connect the idle SM8850 phone and run `adb devices`.
3. Run `.\\Run-SharedStudy.ps1 -SetupNotes "screen off; charging; describe cooling"` (replace notes with actual conditions).
4. Return the whole new `returned-shared-*` directory to Linux, including failures.

The validation package contains only 10 existing development images. Final images
are included only in the separately gated final package. Validation must pass
Linux audit before final evaluation. Validation records are saved by trial; there
is no manually restored or hardcoded old validation marker.

Temperatures are recorded; Android thermal management remains enabled. There is
no 40 C starting gate and no latency or power claim. Use the same handset/build for
validation and final acquisition. Preserve all returned evidence. Use `-SkipPush`
only after a complete transfer; it still verifies the remote payload.

QAIRT files are for local licensed use. Keep proprietary runtime/model packaging
separate from any public paper supplement.
''')
    manifest={'schema':1,'id':bundle.name,'mode':mode,'protocol_sha256':sha256(EXP/'protocol.json'),
              'artifact_freeze_sha256':sha256(EXP/'artifact-freeze.json'),
              'execution_identity_sha256':freeze['execution_identity_sha256'],
              'runtime_source_manifest_sha256':sha256(RUNTIME/'manifest.json'),
              'candidates':candidates,'validation_candidates':list(candidates),'jobs':jobs,
              'final_data_included':mode=='Final','validation_trial':audit['trial'] if audit else None,
              'thermal_policy':'observation-only; no timing/energy claim',
              'files':{str(p.relative_to(bundle)):sha256(p) for p in sorted(bundle.rglob('*')) if p.is_file()}}
    dump(bundle/'manifest.json',manifest)
    archive=bundle.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
        for p in sorted(bundle.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(bundle.parent)))
    # Independently decompress every member and compare the source bytes/hash.
    import hashlib
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            digest=hashlib.sha256()
            with z.open(name) as f:
                for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
            if digest.hexdigest()!=sha256(bundle.parent/name):raise ValueError('ZIP verification failed')
    result={'directory':str(bundle),'zip':str(archive),'zip_sha256':sha256(archive),
            'zip_bytes':archive.stat().st_size,'manifest_sha256':sha256(bundle/'manifest.json'),
            'mode':mode,'jobs':len(jobs),'candidates':28,'zip_verified':True,'native_execution_pending':True}
    dump(EXP/('windows-'+mode.lower()+'-package.json'),result)
    archive.with_suffix('.zip.sha256').write_text(result['zip_sha256']+'  '+archive.name+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=['Validate','Final'],default='Validate')
    p.add_argument('--validation',type=Path);a=p.parse_args()
    if a.mode=='Final' and not a.validation:p.error('--validation is required for Final')
    build(a.mode,a.validation)
