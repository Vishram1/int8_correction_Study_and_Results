#!/system/bin/sh
set -eu
cd "$(dirname "$0")"
export LD_LIBRARY_PATH="$PWD/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export ADSP_LIBRARY_PATH="$PWD/dsp;/vendor/lib/rfsa/adsp;/system/lib/rfsa/adsp;/dsp"
trial="${1:?trial}"; job="${2:?job}"; candidate="${3:?candidate}"; mode="${4:?mode}"; chunk="${5:-0}"
for token in "$trial" "$job" "$candidate" "$chunk"; do
    case "$token" in ''|*[!a-zA-Z0-9_-]*) echo 'Invalid identifier' >&2; exit 2;; esac
done
test -f "models/$candidate.dlc"
out="outputs/$trial/$job"
test ! -e "$out"
mkdir -p "$out"
printf '%s\n' "$candidate" > "$out/candidate.txt"
printf '%s\n' "$mode" > "$out/mode.txt"
printf '%s\n' "$chunk" > "$out/chunk.txt"
date -u > "$out/device-date.txt"
getconf PAGESIZE > "$out/page-size.txt" 2>&1 || true
for property in ro.product.model ro.soc.model ro.board.platform ro.build.version.release ro.build.version.sdk ro.build.fingerprint; do
    printf '%s=' "$property"; getprop "$property"
done > "$out/device-properties.txt"
dumpsys battery > "$out/battery-before.txt" 2>&1 || true
dumpsys thermalservice > "$out/thermal-before.txt" 2>&1 || true
sha256sum "models/$candidate.dlc" > "$out/model-sha256.txt"
case "$mode" in
 validate-off) list=lists/timing.txt; warmup=2; calls=10; profile=off; save=1 ;;
 validate-basic) list=lists/timing.txt; warmup=2; calls=10; profile=basic; save=1 ;;
 accuracy) list="lists/final-$chunk.txt"; warmup=0; calls=100; profile=off; save=1 ;;
 reference) list=lists/timing-qnn.txt ;;
 *) echo 'Invalid mode' >&2; exit 2 ;;
esac
status=0
if [ "$mode" = reference ]; then
    ./bin/qnn-net-run --model "$PWD/lib/libQnnModelDlc.so" --dlc_path "$PWD/models/$candidate.dlc" \
        --backend "$PWD/lib/libQnnHtp.so" --input_list "$PWD/$list" --output_dir "$PWD/$out/reference" \
        --num_inferences 10 --keep_num_outputs 10 --perf_profile sustained_high_performance \
        > "$out/run.log" 2>&1 || status=$?
else
    ./bin/qnn-memory-runner --backend "$PWD/lib/libQnnHtp.so" --system "$PWD/lib/libQnnSystem.so" \
        --dlc "$PWD/models/$candidate.dlc" --inputs "$list" --out "$out" --profile "$profile" \
        --perf htp-turbo --warmup "$warmup" --calls "$calls" --save-logits "$save" \
        > "$out/run.log" 2>&1 || status=$?
fi
printf '%s\n' "$status" > "$out/exit-status.txt"
dumpsys battery > "$out/battery-after.txt" 2>&1 || true
dumpsys thermalservice > "$out/thermal-after.txt" 2>&1 || true
echo "$out (exit $status)"
exit "$status"
