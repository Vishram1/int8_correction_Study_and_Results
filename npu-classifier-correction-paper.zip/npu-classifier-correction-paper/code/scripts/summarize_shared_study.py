"""All-arm reports, paired class uncertainty, and transparent preparation costs."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from shared_common import *


def paired_ci(difference, labels, seed=2026101499, repetitions=10000):
    """Paired class-cluster interval conditional on the observed calibration panel.

    difference is one correctness difference per image, possibly averaged across
    fixed targets first. Each bootstrap draw samples classes and retains all
    within-class images and the same targets/arms. No calibration-population CI.
    """
    difference=np.asarray(difference,dtype=np.float64);labels=np.asarray(labels)
    if difference.shape!=labels.shape or not np.isfinite(difference).all():raise ValueError('Invalid paired observations')
    classes=np.unique(labels)
    sums=np.array([difference[labels==c].sum() for c in classes])
    counts=np.array([(labels==c).sum() for c in classes])
    rng=np.random.default_rng(seed);values=[]
    for offset in range(0,repetitions,100):
        draws=rng.integers(0,len(classes),size=(min(100,repetitions-offset),len(classes)))
        values.extend(100*sums[draws].sum(1)/counts[draws].sum(1))
    return [float(x) for x in np.percentile(values,[2.5,97.5])]


def panel(correct, labels, targets, intervals):
    # Dimensions are target, arm, image; identical observations paired everywhere.
    scores=100*np.mean(correct,axis=2);rows=[];contrasts=[];aggregates=[]
    pairs=[('shared','single'),('shared','refit'),('shared','average'),('single','refit'),
           ('shared','head-reencode'),('shared','baseline'),('shared','bias-refit')]
    for t,target in enumerate(targets):
        for a,arm in enumerate(ARMS):
            rows.append({'target':target,'arm':arm,'top1_pct':float(scores[t,a]),
                         'minus_baseline_pp':float(scores[t,a]-scores[t,0])})
    for left,right in pairs:
        differences=correct[:,ARMS.index(left)].astype(float)-correct[:,ARMS.index(right)].astype(float)
        effects=100*differences.mean(1)
        for t,target in enumerate(targets):
            contrasts.append({'target':target,'contrast':left+'-minus-'+right,'effect_pp':float(effects[t]),
                              'pointwise_ci95_pp':paired_ci(differences[t],labels) if intervals else None})
        aggregates.append({'contrast':left+'-minus-'+right,'mean_effect_pp':float(effects.mean()),
                           'worst_observed_effect_pp':float(effects.min()),'best_observed_effect_pp':float(effects.max()),
                           'conditional_mean_ci95_pp':paired_ci(differences.mean(0),labels) if intervals else None,
                           'observed_targets':len(targets)})
    return {'rows':rows,'contrasts':contrasts,'aggregates':aggregates,
            'interval_scope':'pointwise image/class uncertainty conditional on fixed target calibrations; not simultaneous or calibration-population intervals',
            'formal_noninferiority_claim':False,'descriptive_loss_budget_pp':protocol()['analysis']['loss_budget_pp']}


def summarize(stage, native=None):
    p=protocol();split='selection' if stage=='development' else 'final'
    with (EXP/(split+'.csv')).open() as f:labels=np.array([int(r['label']) for r in csv.DictReader(f)])
    report={'stage':stage,'n':len(labels),'protocol_sha256':sha256(EXP/'protocol.json'),'host':{},'native':{},'costs':{}}
    for model in MODELS:
        logits=[]
        for target in TARGETS:
            rows=[]
            for arm in ARMS:
                out=candidate_dir(model,target,arm)
                if stage=='development':
                    if not complete(out/'host-result.json'):raise ValueError('Host matrix incomplete')
                    path=out/'logits.npy'
                else:
                    result=EXP/'final'/model/target/(arm+'-result.json')
                    if not complete(result):raise ValueError('Final host matrix incomplete')
                    path=result.parent/(arm+'.npy')
                values=np.load(path)
                if values.shape!=(len(labels),1000) or not np.isfinite(values).all():raise ValueError('Invalid logits')
                rows.append(values.argmax(1)==labels)
            logits.append(rows)
        report['host'][model]=panel(np.asarray(logits),labels,TARGETS,stage=='final')
        report['costs'][model]={'cache_records':{v:json.loads((EXP/model/v/'cache-result.json').read_text()) for v in (*SOURCES,*TARGETS)},
            'fits':json.loads((EXP/model/'fits/result.json').read_text()),
            'exports':[{k:v for k,v in json.loads((out/'host-result.json').read_text()).items() if k in ('id','target','source','treatment','seconds')}
                       for m,t,a,out in matrix() if m==model],
            'note':'Preparation stages, not controlled speed benchmarks; A/B costs are historical. Data collection cached target features even for arms whose fitting does not require them.'}
    if native:
        r=json.loads(Path(native).read_text())
        if r['status']!='passed' or r['mode']!='Final':raise ValueError('Expected completed native final audit')
        from shared_delivery import validation_gate
        validation_gate(EXP/'device'/json.loads((Path(r['returned_directory'])/'manifest.json').read_text())['validation_trial']/'report.json')
        for model in MODELS:
            correct=[]
            for target in p['native_targets']:
                rows=[]
                for arm in ARMS:
                    name=model+'__'+target+'__'+arm+'.npy';path=Path(native).parent/name
                    if sha256(path)!=r['arrays_sha256'][name]:raise ValueError('Native scored array changed')
                    values=np.load(path)
                    if values.shape!=(len(labels),1000):raise ValueError('Native array shape mismatch')
                    rows.append(values.argmax(1)==labels)
                correct.append(rows)
            report['native'][model]=panel(np.asarray(correct),labels,p['native_targets'],True)
        report['native_report_sha256']=sha256(native)
    path=EXP/('summary-'+stage+('-with-native' if native else '')+'.json');dump(path,report)
    lines=['# Shared-correction '+stage+' report','',
           'All planned targets and arms are retained. Development results are implementation evidence; final evaluation remains separate.',
           '', '| Backend / model | Contrast | Mean pp | Worst observed pp |','|---|---|---:|---:|']
    for backend in ('host','native'):
        for model,values in report[backend].items():
            for c in values['aggregates']:
                lines.append(f"| {backend} / {model} | {c['contrast']} | {c['mean_effect_pp']:+.3f} | {c['worst_observed_effect_pp']:+.3f} |")
    lines += ['', 'Detailed per-target results and preparation costs are in the accompanying JSON. No power or inference-latency claim is made.']
    path.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(path)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stage',choices=['development','final'],default='development')
    p.add_argument('--native',type=Path);a=p.parse_args()
    if a.native and a.stage!='final':p.error('--native requires --stage final')
    summarize(a.stage,a.native)
