"""Isolated recalibration-reuse pilot. Final image access is deliberately absent."""
from pathlib import Path
import csv
import hashlib
import json
import time

import numpy as np
from pilot_common import ROOT, sha256, source_model, ort_options

EXP = ROOT / 'experiments/recalibration-reuse-20261006-v1'
OLD = ROOT / 'experiments/imagenetv2-20260928'
MODELS = ('mobilenet_v2', 'resnet18')


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def read_rows(split):
    if split not in ('calibration', 'selection'):
        raise ValueError('Only calibration/adaptation and development images are allowed')
    p = OLD / 'data' / (split + '.csv')
    meta = json.loads((OLD / 'data/dataset.json').read_text())
    if sha256(p) != meta['manifest_sha256'][p.name]:
        raise ValueError('Original data manifest changed')
    with p.open() as stream:
        return list(csv.DictReader(stream))


def inputs(split):
    records = read_rows(split)
    p = OLD / 'cache' / (split + '.npy')
    expected = {'manifest': sha256(OLD / 'data' / (split + '.csv')),
                'preprocess': sha256(ROOT / 'scripts/pilot_common.py'), 'count': len(records)}
    if json.loads(p.with_suffix('.json').read_text()) != expected:
        raise ValueError('Input cache provenance mismatch; do not silently regenerate')
    data = np.load(p, mmap_mode='r')
    if data.shape != (len(records), 3, 224, 224) or data.dtype != np.float32:
        raise ValueError('Input cache shape/dtype mismatch')
    return data


def protocol():
    path = EXP / 'protocol.json'
    if sha256(path) != (EXP / 'protocol.sha256').read_text().split()[0]:
        raise ValueError('Frozen pilot protocol changed')
    return json.loads(path.read_text())


def save_result(path, result, artifacts=()):
    result = {**result, 'protocol_sha256': sha256(EXP / 'protocol.json'),
              'implementation_sha256': sha256(ROOT / 'scripts/recalibration_pilot.py'),
              'artifacts': {str(Path(p).relative_to(EXP)): sha256(p) for p in artifacts}}
    dump(path, result)


def complete(path):
    if not path.exists():
        return False
    data = json.loads(path.read_text())
    if data['protocol_sha256'] != sha256(EXP / 'protocol.json'):
        raise ValueError('Result belongs to a different protocol')
    for name, expected in data.get('artifacts', {}).items():
        if sha256(EXP / name) != expected:
            raise ValueError('Completed artifact changed: ' + name)
    return True


def metrics(logits, split='selection'):
    labels = np.array([int(r['label']) for r in read_rows(split)])
    if logits.shape != (len(labels), 1000) or not np.isfinite(logits).all():
        raise ValueError('Invalid logits')
    return {'n': len(labels), 'correct': int((logits.argmax(1) == labels).sum()),
            'top1_pct': float(100 * np.mean(logits.argmax(1) == labels)),
            'tie_count': int(((logits == logits.max(1)[:, None]).sum(1) > 1).sum())}


def comparison(actual, expected):
    if actual.shape != expected.shape or not np.isfinite(actual).all():
        raise ValueError('Invalid comparison')
    delta = actual.astype(np.float64) - expected.astype(np.float64)
    return {'max_abs': float(np.abs(delta).max()), 'rmse': float(np.sqrt(np.mean(delta**2))),
            'prediction_disagreements': int((actual.argmax(1) != expected.argmax(1)).sum()),
            'bitwise_equal': bool(np.array_equal(actual, expected))}


def fit_affine(features, teacher, ridge):
    """Per-channel least squares plus ridge*Var(h)*(a-1)^2; intercept unpenalized."""
    x, y = np.asarray(features, dtype=np.float64), np.asarray(teacher, dtype=np.float64)
    if x.shape != y.shape or x.ndim != 2 or len(x) < 2 or ridge < 0:
        raise ValueError('Invalid affine fitting inputs')
    mx, my = x.mean(0), y.mean(0)
    xc, yc = x - mx, y - my
    var = np.mean(xc * xc, 0)
    cov = np.mean(xc * yc, 0)
    a = np.ones(x.shape[1], dtype=np.float64)
    valid = var > 1e-12
    a[valid] = (cov[valid] + ridge * var[valid]) / ((1 + ridge) * var[valid])
    b = my - a * mx
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('Nonfinite correction')
    return a.astype(np.float32), b.astype(np.float32)


def fold_affine(weight, bias, a, b):
    weight, bias = np.asarray(weight), np.asarray(bias)
    if weight.ndim != 2 or weight.shape[1] != len(a) or a.shape != b.shape or bias.shape != (weight.shape[0],):
        raise ValueError('Classifier fold dimensions mismatch')
    return np.asarray(weight * a[None, :], np.float32), np.asarray(bias + weight @ b, np.float32)
