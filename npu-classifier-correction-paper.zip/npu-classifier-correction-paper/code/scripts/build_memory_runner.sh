#!/usr/bin/env bash
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
sdk="$root/tools/qairt/2.45.41.260507"
ndk="$root/tools/android-ndk-r26d"
out="$root/runner/build"
mkdir -p "$out"
common=(-std=c++17 -O2 -Wall -Wextra -Werror -I "$sdk/include/QNN" "$root/runner/qnn_memory_runner.cpp" -ldl)
g++ "${common[@]}" -o "$out/qnn-memory-runner-linux"
"$ndk/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android28-clang++" "${common[@]}" -static-libstdc++ -Wl,-z,max-page-size=16384 -o "$out/qnn-memory-runner-android"
"$out/qnn-memory-runner-linux" --help
sha256sum "$root/runner/qnn_memory_runner.cpp" "$out/"qnn-memory-runner-*
