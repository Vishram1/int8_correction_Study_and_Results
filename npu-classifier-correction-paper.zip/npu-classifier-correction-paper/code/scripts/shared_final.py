"""One gated host final evaluation of frozen artifacts; never fits a correction."""
import argparse
import gc
import json
import time
from pathlib import Path
import numpy as np
import onnx
import onnxruntime as ort
from aimet_onnx.quantsim import QuantizationSimModel, load_encodings_to_sim
from shared_common import *
from shared_delivery import validation_gate, final_inputs
from shared_pipeline import classifier, add_taps, run_logits, announce
from shared_export import sliced_head


def load_sim(out):
    sim=QuantizationSimModel(onnx.load(out/'model.onnx'),param_type='int8',activation_type='int8',
        quant_scheme='tf_enhanced',config_file='htp_v81',providers=['CPUExecutionProvider'],
        session_options_kwargs={'intra_op_num_threads':4,'inter_op_num_threads':1})
    load_encodings_to_sim(sim,str(out/'model.encodings'),strict=True)
    return sim


def evaluate(model, validation):
    audit=validation_gate(validation);data=final_inputs(validation);head,_,_=classifier(model)
    teacher=EXP/'final'/model/'fp32';record=teacher/'result.json'
    if not complete(record):
        start=time.perf_counter();teacher.mkdir(parents=True,exist_ok=True)
        session=ort.InferenceSession(str(source_model(model)),sess_options=ort_options(),providers=['CPUExecutionProvider'])
        logits=run_logits(session,data);np.save(teacher/'logits.npy',logits)
        save_result(record,{'n':7000,'seconds':time.perf_counter()-start,'stage':'final FP32 reference',
                            'validation_trial':audit['trial']},[teacher/'logits.npy'])
        del session;gc.collect()
    for target in TARGETS:
        out=EXP/'final'/model/target;record=out/'cache-result.json'
        if not complete(record):
            start=time.perf_counter();out.mkdir(parents=True,exist_ok=True)
            sim=load_sim(candidate_dir(model,target,'baseline'))
            original=run_logits(sim.session,data[:32])
            taps=add_taps(sim.model.model,head);sim._rebuild_session()
            check=comparison(run_logits(sim.session,data[:32]),original)
            if check['max_abs']>1e-5 or check['prediction_disagreements']:raise ValueError('Final feature tap changed outputs')
            name=sim.session.get_inputs()[0].name;output=sim.session.get_outputs()[0].name
            features=np.empty((7000,head['dimension']),dtype=np.float32);logits=np.empty((7000,1000),dtype=np.float32)
            for i in range(7000):
                z,h=sim.session.run([output,taps['feature']],{name:data[i:i+1]})
                logits[i]=z[0];features[i]=h.reshape(-1)
                if (i+1)%1000==0:announce(f'{model} {target} final features {i+1}/7000')
            if not np.isfinite(logits).all() or not np.isfinite(features).all():raise ValueError('Nonfinite final outputs')
            np.save(out/'features.npy',features);np.save(out/'baseline.npy',logits)
            save_result(record,{'n':7000,'seconds':time.perf_counter()-start,'tap_check':check,
                'validation_trial':audit['trial']},[out/'features.npy',out/'baseline.npy'])
            del sim;gc.collect()
        features=np.load(out/'features.npy',mmap_mode='r')
        for arm in ARMS:
            result=out/(arm+'-result.json');path=out/(arm+'.npy')
            if complete(result):continue
            start=time.perf_counter();candidate=candidate_dir(model,target,arm)
            sim=load_sim(candidate);session=sliced_head(sim,head,out/(arm+'-runtime'))
            logits=run_logits(session,features)
            check=comparison(logits[:32],run_logits(sim.session,data[:32]))
            if check['max_abs']>1e-5 or check['prediction_disagreements']:raise ValueError('Final full graph/head mismatch')
            if arm=='baseline' and not np.array_equal(logits,np.load(out/'baseline.npy')):
                raise ValueError('Final baseline head reconstruction mismatch')
            if not np.isfinite(logits).all():raise ValueError('Nonfinite final logits')
            np.save(path,logits)
            save_result(result,{'model':model,'target':target,'arm':arm,'n':7000,
                'source_host_result_sha256':sha256(candidate/'host-result.json'),
                'full_graph_check':check,'seconds':time.perf_counter()-start,'validation_trial':audit['trial']},[path])
            del session,sim;gc.collect()
        announce(model+' '+target+' final arms complete')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--model',choices=MODELS,required=True)
    p.add_argument('--validation',type=Path,required=True);a=p.parse_args();evaluate(a.model,a.validation)
