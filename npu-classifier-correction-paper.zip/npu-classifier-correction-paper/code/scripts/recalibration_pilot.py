"""Reproduce, cache and fit a frozen two-calibration classifier-reuse pilot."""
import argparse
import copy
import csv
import gc
import hashlib
import json
import platform
import shutil
import time
from datetime import datetime, timezone

import numpy as np
import onnx
import onnxruntime as ort
from PIL import Image
from aimet_onnx.quantsim import load_encodings_to_sim
from host_experiments import make_sim, calibrate
from pilot_common import image_input
from recalibration_common import (ROOT, EXP, OLD, MODELS, dump, sha256, source_model,
    ort_options, read_rows, inputs, protocol, save_result, complete, metrics,
    comparison, fit_affine, fold_affine)


def announce(message):
    print(datetime.now(timezone.utc).isoformat(timespec='seconds'), message, flush=True)


def classifier(model):
    graph = onnx.load(source_model(model))
    node = graph.graph.node[-1]
    if node.op_type != 'Gemm' or len(node.input) != 3:
        raise ValueError('Unsupported classifier; inspect without changing protocol')
    attrs = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
    if attrs.get('transB', 0) != 1 or attrs.get('transA', 0) != 0 or attrs.get('alpha', 1) != 1 or attrs.get('beta', 1) != 1:
        raise ValueError('Unsupported classifier orientation')
    tensors = {t.name: onnx.numpy_helper.to_array(t) for t in graph.graph.initializer}
    w, b = tensors[node.input[1]], tensors[node.input[2]]
    return {'node': node.name, 'feature': node.input[0], 'weight': node.input[1],
            'bias': node.input[2], 'logits': node.output[0], 'dimension': int(w.shape[1])}, w, b


def prepare():
    if (EXP / 'protocol.json').exists():
        protocol()
        announce('Existing frozen protocol verified')
        return
    EXP.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    records = {s: read_rows(s) for s in ('calibration', 'selection')}
    dataset = json.loads((OLD / 'data/dataset.json').read_text())
    final_manifest = OLD / 'data/final.csv'
    if sha256(final_manifest) != dataset['manifest_sha256']['final.csv']:
        raise ValueError('Final manifest changed')
    # Identity metadata only: never open a final image or final input cache.
    with final_manifest.open() as stream:
        final_rows = list(csv.DictReader(stream))
    all_rows = {**records, 'final_metadata_only': final_rows}
    for field in ('path', 'sha256', 'pixel_sha256'):
        keys = list(all_rows)
        for i, a in enumerate(keys):
            aset = {r[field] for r in all_rows[a]}
            for b in keys[i+1:]:
                if aset & {r[field] for r in all_rows[b]}:
                    raise ValueError('Cross-split identity overlap: ' + field)
    caches = {s: inputs(s) for s in records}
    for split, rows in records.items():
        for i, r in enumerate(rows):
            path = ROOT / r['path']
            if sha256(path) != r['sha256']:
                raise ValueError('Source image hash changed')
            with Image.open(path) as image:
                rgb = image.convert('RGB')
                h = hashlib.sha256(str(rgb.size).encode() + b'\0' + rgb.tobytes()).hexdigest()
            if h != r['pixel_sha256'] or not np.array_equal(image_input(r['path'])[0], caches[split][i]):
                raise ValueError('Decoded pixels or input cache differs')
            if (i + 1) % 500 == 0:
                announce(f'Audited {split} {i+1}/{len(rows)}')
    sources = {}
    for model in MODELS:
        saved = OLD / 'host' / model / 'w8a8-enhanced'
        r = json.loads((saved / 'result.json').read_text())
        checks = {source_model(model): r['provenance']['source'],
                  source_model(model).with_suffix('.data'): r['provenance']['weights'],
                  saved / 'model.encodings': r['encoding_sha256']}
        checks.update({ROOT / 'scripts' / name: value for name, value in r['provenance']['code'].items()})
        for path, expected in checks.items():
            if sha256(path) != expected:
                raise ValueError('Original source/provenance changed: ' + str(path))
        head, _, _ = classifier(model)
        sources[model] = {'files': {str(p.relative_to(ROOT)): h for p, h in checks.items()},
                          'saved_logits_sha256': sha256(saved / 'logits.npy'), 'classifier': head}
    variants = {}
    for name, seed in [('cal-a', 2026100601), ('cal-b', 2026100602)]:
        indices = sorted(np.random.default_rng(seed).choice(1000, 500, replace=False).tolist())
        variants[name] = {'seed': seed, 'indices': indices, 'n': len(indices)}
    p = {'schema': 1, 'id': EXP.name, 'frozen_utc': datetime.now(timezone.utc).isoformat(),
         'question': 'Does the same small correction retain accuracy after independent INT8 recalibration?',
         'stage': 'two-calibration feasibility pilot; not final evidence', 'models': list(MODELS),
         'calibration': {'scheme': 'tf_enhanced', 'requested_weights_bits': 8, 'requested_activation_bits': 8,
                         'aimet_config': 'htp_v81', 'variants': variants,
                         'overlap_images': len(set(variants['cal-a']['indices']) & set(variants['cal-b']['indices']))},
         'data': {'adaptation': 'original calibration.csv, all 1000 images',
                  'development': 'original selection.csv, all 2000 images; never used for fitting',
                  'reuse': 'Calibration subsets and adaptation share the same 1000-image pool.',
                  'manifest_sha256': dataset['manifest_sha256'],
                  'cache_sha256': {s: sha256(OLD / 'cache' / (s+'.npy')) for s in records},
                  'final_images_opened': 0, 'final_manifest_read_for_duplicate_audit_only': True},
         'fit': {'primary': 'per-feature affine teacher alignment', 'ridge': 0.01,
                 'objective': 'mean((a*h_q+b-h_fp)^2) + ridge*Var(h_q)*(a-1)^2, per channel',
                 'method': 'deterministic closed-form least squares; no label loss or gradients',
                 'constant_channel_rule': 'a=1 when feature variance<=1e-12; b=mean_teacher-mean_student',
                 'selection': 'one fixed ridge; no development-based hyperparameter search',
                 'control': 'mean output-logit bias correction, teacher minus quantized raw classifier logits',
                 'fitting_images': 1000, 'source_to_target_pairs': [['cal-a','cal-a'],['cal-a','cal-b'],['cal-b','cal-a'],['cal-b','cal-b']]},
         'export': {'upstream_encodings': 'Keep each target calibration fixed.',
                    'head_weights': 'Fold into target effective quantized classifier weight and bias, then recompute only classifier weight/output encodings.',
                    'head_calibration_data': 'same 500 images as that target calibration',
                    'identity_control': 'Identity fold reuses original tensors and encodings exactly.',
                    'sdk': '2.45.41.260507', 'grid_repair': 'Do not apply the previous 257/256 override.'},
         'sources': sources, 'environment': {'python': platform.python_version(), 'onnx': onnx.__version__,
                                             'onnxruntime': ort.__version__, 'provider': 'CPUExecutionProvider'},
         'baseline_gate': {'development_images': 2000, 'max_abs_tolerance': 1e-5, 'prediction_disagreements_allowed': 0},
         'metrics': ['accuracy vs each target unchanged A8', 'source-to-target matrix', 'target-refitted minus reused accuracy',
                     'teacher-feature and logit errors', 'folded and native accuracy', 'preparation and fitting costs'],
         'limits': ['Two calibration draws from one pool are a pilot, not broad quantizer robustness.',
                    'No power/energy claim; no device measurements yet.', 'No held-out final data evaluation.']}
    dump(EXP / 'protocol.json', p)
    (EXP / 'protocol.sha256').write_text(sha256(EXP/'protocol.json') + '  protocol.json\n')
    for split in records:
        shutil.copyfile(OLD/'data'/(split+'.csv'), EXP/(split+'.csv'))
    save_result(EXP / 'data-audit.json', {'status': 'passed', 'source_images_verified': 3000,
                'pixel_and_preprocessing_verified': 3000, 'cross_split_duplicates': 0,
                'final_images_opened': 0, 'seconds': time.perf_counter()-start},
                [EXP/'calibration.csv', EXP/'selection.csv'])
    announce('Frozen pilot protocol and image/cache audit complete')


def run_logits(session, data, output=None):
    out = output or session.get_outputs()[0].name
    result = np.empty((len(data), 1000), dtype=np.float32)
    name = session.get_inputs()[0].name
    for i in range(len(data)):
        result[i] = session.run([out], {name: data[i:i+1]})[0][0]
        if (i+1) % 500 == 0:
            announce(f'Logits {i+1}/{len(data)}')
    return result


def reproduce(model):
    out = EXP / model / 'reproduction'
    if complete(out / 'result.json'):
        return
    p = protocol(); saved = OLD/'host'/model/'w8a8-enhanced'
    sim = make_sim(model, 8, 'tf_enhanced')
    load_encodings_to_sim(sim, str(saved/'model.encodings'), strict=True)
    start = time.perf_counter()
    logits = run_logits(sim.session, inputs('selection'))
    report = comparison(logits, np.load(saved/'logits.npy'))
    dump(out/'comparison.json', report)
    gate = p['baseline_gate']
    if report['max_abs'] > gate['max_abs_tolerance'] or report['prediction_disagreements']:
        raise ValueError('Saved baseline reproduction failed; inspect comparison.json')
    np.save(out/'logits.npy', logits)
    save_result(out/'result.json', {'status': 'passed', 'comparison': report,
                 'metrics': metrics(logits), 'seconds': time.perf_counter()-start}, [out/'logits.npy'])
    announce(model + ' saved baseline reproduced: ' + str(report))
    del sim; gc.collect()


def add_taps(graph, head):
    node = next(n for n in graph.graph.node if n.name == head['node'])
    taps = {'feature': node.input[0], 'weight': node.input[1], 'bias': node.input[2], 'raw_logits': node.output[0]}
    shapes = {'feature': [1, head['dimension']], 'weight': [1000, head['dimension']], 'bias': [1000], 'raw_logits': [1, 1000]}
    existing = {x.name for x in graph.graph.output}
    for key, name in taps.items():
        if name not in existing:
            graph.graph.output.append(onnx.helper.make_tensor_value_info(name, onnx.TensorProto.FLOAT, shapes[key]))
    return taps


def extract(model, variant):
    out = EXP / model / variant
    if complete(out/'cache-result.json'):
        return
    if not complete(EXP/model/'reproduction/result.json'):
        raise ValueError('Baseline reproduction must pass before new features')
    p = protocol(); head, _, _ = classifier(model); start = time.perf_counter()
    if variant == 'fp32':
        graph = onnx.load(source_model(model))
        original = ort.InferenceSession(graph.SerializeToString(), sess_options=ort_options(), providers=['CPUExecutionProvider'])
        original_logits = run_logits(original, inputs('selection')[:32]); del original
        taps = add_taps(graph, head)
        session = ort.InferenceSession(graph.SerializeToString(), sess_options=ort_options(), providers=['CPUExecutionProvider'])
        sim = None
    else:
        if variant not in p['calibration']['variants']:
            raise ValueError('Unregistered calibration')
        sim = make_sim(model, 8, 'tf_enhanced')
        indices = p['calibration']['variants'][variant]['indices']
        announce(model+' '+variant+' calibrating 500 images')
        calibrate(sim, inputs('calibration')[indices])
        out.mkdir(parents=True, exist_ok=True)
        sim.export(str(out), 'model', encoding_version='1.0.0')
        original_logits = run_logits(sim.session, inputs('selection')[:32])
        taps = add_taps(sim.model.model, head)
        sim._rebuild_session()
        session = sim.session
    out.mkdir(parents=True, exist_ok=True)
    output = session.get_outputs()[0].name
    tapped_logits = run_logits(session, inputs('selection')[:32], output)
    check = comparison(tapped_logits, original_logits)
    if check['max_abs'] > 1e-5 or check['prediction_disagreements']:
        dump(out/'tap-failure.json', check)
        raise ValueError('Exposing features changed classifier outputs')
    in_name = session.get_inputs()[0].name
    names = [output, taps['feature'], taps['raw_logits']]
    files = []
    for split in ('calibration', 'selection'):
        data = inputs(split)
        features = np.empty((len(data), head['dimension']), dtype=np.float32)
        logits = np.empty((len(data), 1000), dtype=np.float32)
        raw_logits = np.empty_like(logits)
        for i in range(len(data)):
            z, h, raw = session.run(names, {in_name: data[i:i+1]})
            logits[i], features[i], raw_logits[i] = z[0], h.reshape(-1), raw[0]
            if (i+1) % 500 == 0:
                announce(f'{model} {variant} {split} features {i+1}/{len(data)}')
        for name, values in [('features',features), ('logits',logits), ('raw-logits',raw_logits)]:
            if not np.isfinite(values).all():
                raise ValueError('Nonfinite cached features/outputs')
            path = out/(split+'-'+name+'.npy'); np.save(path, values); files.append(path)
    w, b = session.run([taps['weight'], taps['bias']], {in_name: inputs('calibration')[:1]})
    np.savez(out/'head.npz', weight=w, bias=b)
    h = np.load(out/'selection-features.npy')
    raw = np.load(out/'selection-raw-logits.npy')
    head_check = comparison(h @ w.T + b, raw)
    if head_check['max_abs'] > 1e-4:
        raise ValueError('Cached classifier does not reproduce simulated raw logits')
    if variant == 'fp32':
        ref_check = comparison(np.load(out/'selection-logits.npy'), np.load(OLD/'host'/model/'fp32.npy'))
        if ref_check['max_abs'] > 1e-5 or ref_check['prediction_disagreements']:
            raise ValueError('Floating-point teacher differs from saved reference')
    else:
        ref_check = None; files += [out/'model.onnx', out/'model.encodings']
    files.append(out/'head.npz')
    save_result(out/'cache-result.json', {'status':'passed','model':model,'variant':variant,
            'taps':taps,'feature_kind':'dequantized classifier input' if sim is not None else 'FP32 classifier input',
            'tap_identity':check,'cached_head_check':head_check,'fp32_reference_check':ref_check,
            'metrics':metrics(np.load(out/'selection-logits.npy')),'seconds':time.perf_counter()-start}, files)
    announce(model+' '+variant+' cache complete')
    del session,sim;gc.collect()


def fit(model):
    out = EXP/model/'fits';p=protocol()
    if complete(out/'result.json'):
        return
    for variant in ('fp32',*p['calibration']['variants']):
        if not complete(EXP/model/variant/'cache-result.json'):
            raise ValueError('Feature cache is incomplete')
    out.mkdir(parents=True,exist_ok=True);start=time.perf_counter()
    teacher = np.load(EXP/model/'fp32/calibration-features.npy')
    teacher_z = np.load(EXP/model/'fp32/calibration-logits.npy')
    rows=[];files=[]
    for source in p['calibration']['variants']:
        folder=EXP/model/source
        a,b=fit_affine(np.load(folder/'calibration-features.npy'), teacher, p['fit']['ridge'])
        bias=np.mean(teacher_z.astype(np.float64)-np.load(folder/'calibration-raw-logits.npy').astype(np.float64),axis=0).astype(np.float32)
        path=out/(source+'.npz');np.savez(path,a=a,b=b,output_bias=bias);files.append(path)
        for target in p['calibration']['variants']:
            dest=EXP/model/target
            h=np.load(dest/'selection-features.npy');head=np.load(dest/'head.npz');w,c=head['weight'],head['bias']
            target_base=np.load(dest/'selection-logits.npy')
            unquantized_head=h@w.T+c
            for method,logits in [('affine',(h*a+b)@w.T+c),('output-bias',unquantized_head+bias)]:
                file=out/(source+'__'+target+'__'+method+'-float-head.npy');np.save(file,logits);files.append(file)
                rows.append({'source':source,'target':target,'method':method,'stage':'float corrected head on quantized features; output quantizer bypassed',
                             'metrics':metrics(logits),'raw_head_baseline':metrics(unquantized_head),
                             'fully_quantized_baseline':metrics(target_base)})
    save_result(out/'result.json',{'status':'complete','model':model,'method':p['fit'],'seconds':time.perf_counter()-start,
                                 'rows':rows,'limitation':'These are float-head diagnostics; folded INT8/device results are separate.'}, files)
    announce(model+' two-calibration affine fits complete')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['prepare','reproduce','cache','fit','host'])
    parser.add_argument('--model',choices=MODELS,default='mobilenet_v2')
    args=parser.parse_args()
    if args.stage in ('prepare','host'):prepare()
    if args.stage in ('reproduce','host'):reproduce(args.model)
    if args.stage in ('cache','host'):
        for variant in ('fp32','cal-a','cal-b'):extract(args.model,variant)
    if args.stage in ('fit','host'):fit(args.model)


if __name__=='__main__':
    main()
