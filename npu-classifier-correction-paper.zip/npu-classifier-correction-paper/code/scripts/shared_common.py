"""Prospective multi-calibration extension; original pilot remains immutable."""
from pathlib import Path
import json
import numpy as np
from recalibration_common import (ROOT, OLD, MODELS, dump, sha256, source_model,
    ort_options, read_rows, inputs, metrics, comparison, fold_affine, fit_affine)

PREVIOUS = ROOT / 'experiments/recalibration-reuse-20261006-v1'
EXP = ROOT / 'experiments/recalibration-shared-20261014-v1'
SOURCES = ('cal-a', 'cal-b', 'source-c')
TARGETS = tuple('target-' + str(i) for i in range(1, 6))
ARMS = ('baseline', 'head-reencode', 'single', 'average', 'shared', 'refit', 'bias-refit')


def protocol():
    p = EXP / 'protocol.json'
    if sha256(p) != (EXP / 'protocol.sha256').read_text().split()[0]:
        raise ValueError('Extension protocol changed')
    return json.loads(p.read_text())


def save_result(path, result, artifacts=()):
    result = {**result, 'protocol_sha256': sha256(EXP/'protocol.json'),
              'artifacts': {str(Path(p).relative_to(EXP)): sha256(p) for p in artifacts}}
    dump(path, result)


def complete(path):
    if not path.exists():
        return False
    value = json.loads(path.read_text())
    if value['protocol_sha256'] != sha256(EXP/'protocol.json'):
        raise ValueError('Result protocol mismatch: ' + str(path))
    for rel, digest in value.get('artifacts', {}).items():
        if sha256(EXP/rel) != digest:
            raise ValueError('Completed artifact changed: ' + rel)
    return True


def fit_shared(features, teacher, ridge=0.01):
    """Minimize mean source MSE + ridge*mean(within-source variance)*(a-1)^2.

    Each source contains the same adaptation images in the same order. The
    intercept is shared and unpenalized. Calculations use float64; stored
    parameters use float32, as in the original single-source procedure.
    """
    x = np.asarray(features, dtype=np.float64)
    y = np.asarray(teacher, dtype=np.float64)
    if (x.ndim != 3 or y.ndim != 2 or x.shape[1:] != y.shape or
            x.shape[0] < 1 or x.shape[1] < 2 or not np.isfinite(ridge) or ridge < 0 or
            not np.isfinite(x).all() or not np.isfinite(y).all()):
        raise ValueError('Invalid shared fit inputs')
    mx, my = x.mean(axis=(0, 1)), y.mean(0)
    xc, yc = x - mx, y - my
    variance = np.mean(xc * xc, axis=(0, 1))
    within = np.mean(np.var(x, axis=1), axis=0)
    covariance = np.mean(xc * yc[None], axis=(0, 1))
    penalty = ridge * within
    a = np.ones(y.shape[1], dtype=np.float64)
    valid = variance > 1e-12
    a[valid] = (covariance[valid] + penalty[valid]) / (variance[valid] + penalty[valid])
    b = my - a * mx
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('Nonfinite shared parameters')
    return a.astype(np.float32), b.astype(np.float32)


def arm_spec(target, arm):
    return {'baseline': ('baseline', None), 'head-reencode': ('head-reencode', None),
            'single': ('affine', 'cal-a'), 'average': ('affine', 'average'),
            'shared': ('affine', 'shared'), 'refit': ('affine', target),
            'bias-refit': ('output-bias', target)}[arm]


def candidate_dir(model, target, arm):
    treatment, source = arm_spec(target, arm)
    return EXP/model/'deploy'/(target+'__'+treatment+('__'+source if source else ''))


def matrix(native=False):
    targets = protocol()['native_targets'] if native else TARGETS
    return [(m, t, a, candidate_dir(m, t, a)) for m in MODELS for t in targets for a in ARMS]
