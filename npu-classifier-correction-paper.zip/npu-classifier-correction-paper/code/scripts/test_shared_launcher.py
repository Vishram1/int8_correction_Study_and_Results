"""PowerShell control-flow tests with synthetic transport fixtures, never a phone.

All mock tensors live in temporary test directories. They are not research data
or experimental results and are never copied into a study report or package.
"""
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from shared_common import ROOT, sha256

PWSH=os.environ.get('SHARED_TEST_PWSH',str(ROOT/'tools/powershell-7.6.7/pwsh'))
MOCK=r'''
$a=@($args)
if ($a[0] -eq "-s") { $a=$a[2..($a.Count-1)] }
$global:LASTEXITCODE=0
if ($a[0] -eq "get-state") { "device"; return }
if ($a[0] -eq "get-serialno") { "unit-test-handset"; return }
if ($a[0] -eq "shell" -and $a[1] -eq "getprop") {
    if ($a[2] -eq "ro.soc.model") { "SM8850" } else { "unit-test-build" }; return
}
if ($a[0] -eq "shell" -and $a[1] -eq "date") { "unit-test-clock"; return }
if ($a[0] -eq "shell" -and $a[1] -eq "sha256sum") {
    (Get-FileHash (Join-Path $PSScriptRoot "payload-sha256.txt")).Hash.ToLowerInvariant()+"  payload-sha256.txt"; return
}
if ($a[0] -eq "shell" -and ($a[1].StartsWith("cd ") -or $a[1] -eq "chmod")) { return }
if ($a[0] -eq "shell" -and $a[1] -eq "sh") {
    Add-Content -LiteralPath $env:SHARED_TEST_CALLS -Value $a[4]
    if ($env:SHARED_TEST_CASE -eq "fail-first") { $global:LASTEXITCODE=42; return }
    $folder=Join-Path $env:SHARED_TEST_REMOTE "$($a[3])/$($a[4])"
    New-Item -ItemType Directory -Force -Path $folder | Out-Null
    [IO.File]::WriteAllText((Join-Path $folder "exit-status.txt"),"0`n")
    $digest=(Get-FileHash (Join-Path $PSScriptRoot "models/mock.dlc")).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText((Join-Path $folder "model-sha256.txt"),$digest+"  mock.dlc`n")
    if ($a[6] -eq "reference") {
        for ($i=0;$i -lt 10;$i++) {
            $r=Join-Path $folder "reference/Result_$i"
            New-Item -ItemType Directory -Force -Path $r | Out-Null
            [IO.File]::WriteAllBytes((Join-Path $r "unit-fixture.raw"),(New-Object byte[] 4000))
        }
    } elseif ($a[6] -in @("validate-off","validate-basic")) {
        [IO.File]::WriteAllBytes((Join-Path $folder "logits.f32"),(New-Object byte[] 40000))
        $meta=@{calls=10;warmup=2;perf_api_accepted=$true;backend_build="v2.45.41.260507231357"} | ConvertTo-Json
        [IO.File]::WriteAllText((Join-Path $folder "complete.json"),$meta)
        [IO.File]::WriteAllText((Join-Path $folder "timings.csv"),"phase`nwarmup`nwarmup`n"+("measured`n"*10))
        $events="call,type,unit`n"
        if ($a[6] -eq "validate-basic") { for ($i=0;$i -lt 12;$i++) { $events+="$i,3012,1`n" } }
        [IO.File]::WriteAllText((Join-Path $folder "events.csv"),$events)
    }
    return
}
if ($a[0] -eq "pull") {
    $src=Join-Path $env:SHARED_TEST_REMOTE $a[1].Split('/')[-1]
    if ($env:SHARED_TEST_CASE -eq "pull-fail" -or -not (Test-Path $src)) { $global:LASTEXITCODE=1; return }
    Copy-Item -LiteralPath $src -Destination $a[2] -Recurse; return
}
throw "Unimplemented test transport call"
'''


class LauncherTests(unittest.TestCase):
    def run_case(self, scenario='ok', mode='Validate', wrong_unit=False):
        scratch=tempfile.TemporaryDirectory(prefix='shared-launcher-unit-');self.addCleanup(scratch.cleanup)
        folder=Path(scratch.name);(folder/'models').mkdir();(folder/'models/mock.dlc').write_text('synthetic test fixture, never a model')
        shutil.copy2(ROOT/'scripts/Run-SharedStudy.ps1',folder/'Run-SharedStudy.ps1')
        (folder/'payload-sha256.txt').write_text('unit fixture only')
        (folder/'mock.ps1').write_text(MOCK)
        candidates={'mock':{'dlc_sha256':sha256(folder/'models/mock.dlc')}}
        jobs=[{'id':'mock-'+k,'candidate':'mock','mode':k,'chunk':'0','session':0}
              for k in (('reference','validate-off','validate-basic') if mode=='Validate' else ('accuracy',))]
        manifest={'id':'unit-fixture','mode':mode,'execution_identity_sha256':'synthetic-identity',
                  'candidates':candidates,'validation_candidates':['mock'],'jobs':jobs,
                  'files':{'payload-sha256.txt':sha256(folder/'payload-sha256.txt'),
                           'models/mock.dlc':sha256(folder/'models/mock.dlc')}}
        if mode=='Final':
            audit={'mode':'Validate','status':'passed','execution_identity_sha256':'synthetic-identity',
                   'run':{'device_serial':'wrong-test-unit' if wrong_unit else 'unit-test-handset','device_build':'unit-test-build'}}
            (folder/'validation-audit.json').write_text(json.dumps(audit))
            manifest['files']['validation-audit.json']=sha256(folder/'validation-audit.json')
        (folder/'manifest.json').write_text(json.dumps(manifest))
        env=dict(os.environ,XDG_CACHE_HOME='/tmp/recalibration-pwsh-cache',XDG_CONFIG_HOME='/tmp/recalibration-pwsh-config',
                 XDG_DATA_HOME='/tmp/recalibration-pwsh-data',DOTNET_CLI_HOME='/tmp/recalibration-dotnet',
                 SHARED_TEST_CALLS=str(folder/'calls.txt'),SHARED_TEST_REMOTE=str(folder/'remote'),SHARED_TEST_CASE=scenario)
        result=subprocess.run([PWSH,'-NoLogo','-NoProfile','-File',str(folder/'Run-SharedStudy.ps1'),
                               '-SkipPush','-Adb',str(folder/'mock.ps1')],env=env,capture_output=True,text=True,timeout=25)
        returns=list(folder.glob('returned-shared-*'))
        return folder,result,returns

    def test_validation_record_saved_in_return(self):
        folder,result,returns=self.run_case()
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertEqual(len(returns),1)
        record=json.loads((returns[0]/'validation-record.json').read_text())
        self.assertEqual(record['status'],'passed-local-checks')
        self.assertTrue((folder/('validation-passed-'+record['validation_trial']+'.json')).exists())
        self.assertEqual(json.loads((returns[0]/'complete.json').read_text())['jobs'],3)

    def test_first_job_failure_preserves_return(self):
        folder,result,returns=self.run_case('fail-first')
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(len((folder/'calls.txt').read_text().splitlines()),1)
        self.assertFalse((returns[0]/'complete.json').exists())
        self.assertEqual(len(json.loads((returns[0]/'failed-jobs.json').read_text())),1)

    def test_failed_pull_never_passes(self):
        _,result,returns=self.run_case('pull-fail')
        self.assertNotEqual(result.returncode,0)
        self.assertTrue(json.loads((returns[0]/'acquisition.json').read_text())['pull_failed'])
        self.assertFalse((returns[0]/'validation-record.json').exists())

    def test_final_matching_unit_link(self):
        _,result,returns=self.run_case(mode='Final')
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertTrue((returns[0]/'validation-audit.json').exists())
        self.assertTrue((returns[0]/'complete.json').exists())

    def test_changed_unit_stops_before_jobs_and_preserves_identity(self):
        folder,result,returns=self.run_case(mode='Final',wrong_unit=True)
        self.assertNotEqual(result.returncode,0)
        self.assertFalse((folder/'calls.txt').exists())
        self.assertEqual(json.loads((returns[0]/'run.json').read_text())['device_serial'],'unit-test-handset')


if __name__=='__main__':unittest.main(verbosity=2)
