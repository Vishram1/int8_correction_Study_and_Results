"""Prepare disjoint final-study manifests from user-supplied official validation data.

Does not download restricted data, extract archives or train a model. Requires the
official devkit mapping: its class IDs are not model output indices.
"""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
from scipy.io import loadmat
from pilot_common import ROOT, CLASSES, sha256

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--images',type=Path,required=True,help='Extracted validation JPEG directory (searched recursively)')
    parser.add_argument('--devkit',type=Path,required=True,help='Extracted ILSVRC2012_devkit_t12 directory containing data/meta.mat')
    parser.add_argument('--output',type=Path,default=ROOT/'data/imagenet-final-manifests')
    args=parser.parse_args()
    if args.output.exists():
        raise SystemExit('Output already exists; preserve the frozen split or choose a new output path explicitly.')
    meta=args.devkit/'data/meta.mat'
    truth=args.devkit/'data/ILSVRC2012_validation_ground_truth.txt'
    synsets=loadmat(meta,squeeze_me=True)['synsets']
    leaf=[row for row in synsets if int(row[4])==0]
    official={int(row[0]):str(row[1]) for row in leaf}
    wnids=sorted(official.values())
    if len(set(wnids))!=1000:raise RuntimeError('Expected 1000 unique leaf synsets in official devkit')
    class_index={wnid:i for i,wnid in enumerate(wnids)}
    if any(class_index[k]!=v for k,v in CLASSES.items()):
        raise RuntimeError('Devkit-to-checkpoint label mapping failed known-synset checks')
    ids=[int(line) for line in truth.read_text().splitlines() if line.strip()]
    if len(ids)!=50000:raise RuntimeError('Expected 50000 validation labels')
    paths=sorted(args.images.rglob('ILSVRC2012_val_*.JPEG'))
    by_name={p.name:p.resolve() for p in paths}
    if len(paths)!=50000 or len(by_name)!=50000:
        raise RuntimeError('Expected exactly 50000 uniquely named official validation JPEGs')
    classes=defaultdict(list)
    for i,official_id in enumerate(ids,1):
        name=f'ILSVRC2012_val_{i:08d}.JPEG'
        path=by_name[name];wnid=official[official_id]
        classes[wnid].append({'path':str(path),'label':class_index[wnid],
                              'synset':wnid,'sha256':sha256(path),'official_id':official_id})
    if len(classes)!=1000 or any(len(v)!=50 for v in classes.values()):
        raise RuntimeError('Expected 50 validation examples per class')
    splits={name:[] for name in ('calibration','selection','final')}
    for wnid in wnids:
        examples=sorted(classes[wnid],key=lambda r:hashlib.sha256(('20260927/'+Path(r['path']).name).encode()).hexdigest())
        for name,part in [('calibration',examples[:1]),('selection',examples[1:10]),('final',examples[10:])]:
            splits[name].extend(part)
    seen={}
    for name,records in splits.items():
        for record in records:
            digest=record['sha256']
            if digest in seen and seen[digest]!=name:
                raise RuntimeError('Duplicate image content crosses splits; resolve before freezing: '+record['path'])
            seen[digest]=name
    args.output.mkdir(parents=True)
    for name,records in splits.items():
        # Interleave classes for balanced prefixes, preserving the per-class hash order.
        per_class=len(records)//1000
        records[:]=[records[c*per_class+i] for i in range(per_class) for c in range(1000)]
        with (args.output/f'{name}.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    report={'dataset':'Official ILSVRC2012 validation, repartitioned; not standard 50000-image validation accuracy',
            'seed':'20260927','class_index':class_index,
            'labels_sha256':sha256(truth),'meta_sha256':sha256(meta),
            'counts':{k:len(v) for k,v in splits.items()},
            'cross_split_duplicate_content':0,
            'manifests':{k:sha256(args.output/f'{k}.csv') for k in splits},
            'rule':'Use calibration for ranges, selection for all policy choices, final once after freezing choices.',
            'execution_status':'Manifests prepared; model evaluation is a separate step.'}
    (args.output/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Prepared 1000 calibration / 9000 selection / 40000 final examples at',args.output)

if __name__=='__main__':main()
