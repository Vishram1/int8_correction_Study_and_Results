"""Immutable artifact inventory and validation gate for final-data access."""
import csv
import json
from pathlib import Path
from datetime import datetime, timezone
import shutil
import numpy as np
from shared_common import *

RUNTIME = ROOT/'exports/npu-imagenetv2-20260928'
SCRIPT_NAMES = ['shared_common.py','prepare_shared_study.py','shared_pipeline.py','shared_export.py',
                'shared_delivery.py','build_shared_bundle.py','analyze_shared_return.py',
                'shared_final.py','summarize_shared_study.py','shared_diagnostics.py','test_shared_fit.py','test_shared_delivery.py','test_shared_launcher.py',
                'Run-SharedStudy.ps1','run_shared_device.sh','recalibration_common.py',
                'analyze_recalibration_return.py','pilot_common.py','host_experiments.py',
                'convert_experiments.py','qairt.sh','quantize_pilot.py']


def runtime_files():
    previous=json.loads((RUNTIME/'manifest.json').read_text());paths=[]
    for folder in ('lib','dsp'):
        paths.extend(p for p in (RUNTIME/folder).iterdir() if p.is_file())
    paths += [RUNTIME/'bin/qnn-net-run',RUNTIME/'bin/qnn-memory-runner',RUNTIME/'QAIRT-LICENSE.pdf']
    for p in paths:
        if sha256(p)!=previous['files'][str(p.relative_to(RUNTIME))]:
            raise ValueError('Pinned runtime file changed: '+str(p))
    return paths


def verify_seal():
    protocol();path=EXP/'artifact-freeze.json'
    if sha256(path)!=(EXP/'artifact-freeze.sha256').read_text().split()[0]:
        raise ValueError('Artifact freeze changed')
    freeze=json.loads(path.read_text())
    if freeze['protocol_sha256']!=sha256(EXP/'protocol.json'):
        raise ValueError('Protocol/freeze mismatch')
    for rel,digest in freeze['files'].items():
        if sha256(ROOT/rel)!=digest:
            raise ValueError('Frozen artifact or code changed: '+rel)
    if sha256(EXP/'execution-identity.json')!=freeze['execution_identity_sha256']:
        raise ValueError('Runtime/model identity changed')
    return freeze


def seal():
    if (EXP/'artifact-freeze.json').exists(): return verify_seal()
    protocol();files=set();structure={}
    for model,target,arm,out in matrix():
        if not complete(out/'host-result.json'):raise ValueError('Host matrix incomplete: '+str(out))
        result=json.loads((out/'host-result.json').read_text())
        if result['export_script_sha256']!=sha256(ROOT/'scripts/shared_export.py'):
            raise ValueError('Host export implementation differs from current code')
        files.add(out/'host-result.json')
        files.update(EXP/r for r in json.loads((out/'host-result.json').read_text())['artifacts'])
    for model,target,arm,out in matrix(native=True):
        if not complete(out/'conversion-result.json'):raise ValueError('Native matrix incomplete: '+str(out))
        baseline=json.loads((candidate_dir(model,target,'baseline')/'graph.json').read_text())['graph']
        graph=json.loads((out/'graph.json').read_text())['graph']
        fc=[n for n in baseline['nodes'].values() if n['type']=='FullyConnected' and 'class_logits' in n['output_names']]
        if len(fc)!=1:raise ValueError('Expected one final native classifier')
        allowed=set(fc[0]['input_names'][1:])|set(fc[0]['output_names'])
        if graph['nodes']!=baseline['nodes'] or set(graph['tensors'])!=set(baseline['tensors']):
            raise ValueError('Native graph changed: '+str(out))
        changes=[t for t in graph['tensors'] if graph['tensors'][t]!=baseline['tensors'][t]]
        if set(changes)-allowed:raise ValueError('Native backbone changed: '+str(out))
        structure[model+'__'+target+'__'+arm]={'nodes_identical':True,'tensor_changes':changes,'backbone_unchanged':True}
        files.add(out/'conversion-result.json')
        files.update(EXP/r for r in json.loads((out/'conversion-result.json').read_text())['artifacts'])
    dump(EXP/'native-structure.json',structure);files.add(EXP/'native-structure.json')
    for model in MODELS:
        for name in ('fp32',*SOURCES,*TARGETS):
            record=EXP/model/name/'cache-result.json'
            if not complete(record):raise ValueError('Missing/changed feature cache')
            info=json.loads(record.read_text())
            if 'reused_from' not in info and info['implementation_sha256']!=sha256(ROOT/'scripts/shared_pipeline.py'):
                raise ValueError('New cache implementation differs from current code')
            files.add(record);files.update(EXP/r for r in json.loads(record.read_text())['artifacts'])
        record=EXP/model/'fits/result.json'
        if not complete(record):raise ValueError('Missing/changed fits')
        if json.loads(record.read_text())['implementation_sha256']!=sha256(ROOT/'scripts/shared_pipeline.py'):
            raise ValueError('Fit implementation differs from current code')
        files.add(record);files.update(EXP/r for r in json.loads(record.read_text())['artifacts'])
    for name in SCRIPT_NAMES:
        path=ROOT/'scripts'/name
        dest=EXP/'source/frozen'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
        files.update([path,dest])
    for split in ('calibration','selection','final'):files.add(EXP/(split+'.csv'))
    for model,info in protocol()['sources'].items():
        for rel,digest in info['files'].items():
            if sha256(ROOT/rel)!=digest:raise ValueError('Original source/provenance changed: '+rel)
            files.add(ROOT/rel)
    runtime=runtime_files()
    identity={'schema':1,'protocol_sha256':sha256(EXP/'protocol.json'),
              'models':{m+'__'+t+'__'+a:sha256(out/'quantized.dlc') for m,t,a,out in matrix(native=True)},
              'runtime':{str(p.relative_to(RUNTIME)):sha256(p) for p in runtime},
              'device_runner_sha256':sha256(ROOT/'scripts/run_shared_device.sh'),
              'input_semantics':'float32 NHWC RGB [0,1] 224x224; source model includes normalization',
              'sdk_build':'v2.45.41.260507231357'}
    dump(EXP/'execution-identity.json',identity)
    files.update(runtime)
    result={'frozen_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':sha256(EXP/'protocol.json'),
            'execution_identity_sha256':sha256(EXP/'execution-identity.json'),
            'host_candidates':70,'native_candidates':28,'final_images_evaluated':0,
            'files':{str(p.relative_to(ROOT)):sha256(p) for p in sorted(files)}}
    dump(EXP/'artifact-freeze.json',result)
    (EXP/'artifact-freeze.sha256').write_text(sha256(EXP/'artifact-freeze.json')+'  artifact-freeze.json\n')
    return result


def validation_gate(report_path):
    """Only a successful local audit bound to this frozen artifact set opens final data."""
    freeze=verify_seal();path=Path(report_path).resolve();report=json.loads(path.read_text())
    if path!=EXP/'device'/report.get('trial','')/'report.json':
        raise ValueError('Use the report created by the Linux return analyzer')
    if report.get('status')!='passed' or report.get('mode')!='Validate':
        raise ValueError('Successful native validation is required')
    if report.get('execution_identity_sha256')!=freeze['execution_identity_sha256']:
        raise ValueError('Validation uses different models/runtime')
    if len(report.get('candidates',{}))!=28:
        raise ValueError('Validation did not cover all 28 artifacts')
    audit_code=ROOT/'scripts/analyze_shared_return.py'
    if report.get('analysis_code_sha256')!=sha256(audit_code):
        raise ValueError('Validation audit code differs from frozen implementation')
    returned=Path(report['returned_directory'])
    for rel,digest in report['returned_file_sha256'].items():
        if sha256(returned/rel)!=digest:raise ValueError('Audited validation evidence changed')
    return report


def final_inputs(report_path):
    audit=validation_gate(report_path)
    path=EXP/'final/inputs.npy';record=EXP/'final/inputs.json'
    if complete(record):return np.load(path,mmap_mode='r')
    from pilot_common import image_input
    with (EXP/'final.csv').open() as f:rows=list(csv.DictReader(f))
    if len(rows)!=7000:raise ValueError('Expected 7000 final images')
    started=EXP/'final/access-started.json'
    if not started.exists():
        dump(started,{'utc':datetime.now(timezone.utc).isoformat(),'validation_trial':audit['trial'],
                      'validation_report_sha256':sha256(report_path),
                      'artifact_freeze_sha256':sha256(EXP/'artifact-freeze.json'),
                      'purpose':'one prespecified final evaluation; resumable acquisition, no tuning'})
    path.parent.mkdir(parents=True,exist_ok=True)
    data=np.lib.format.open_memmap(path,mode='w+',dtype=np.float32,shape=(7000,3,224,224))
    for i,row in enumerate(rows):
        if sha256(ROOT/row['path'])!=row['sha256']:raise ValueError('Final source image changed')
        data[i]=image_input(row['path'])[0]
        if (i+1)%1000==0:print('Prepared final inputs',i+1,flush=True)
    data.flush()
    save_result(record,{'n':7000,'manifest_sha256':sha256(EXP/'final.csv'),
                        'validation_report_sha256':sha256(report_path)},[path])
    return np.load(path,mmap_mode='r')
