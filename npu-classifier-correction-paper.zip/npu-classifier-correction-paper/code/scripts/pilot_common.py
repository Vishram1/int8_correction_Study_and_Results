"""Shared pilot inputs: AI Hub graphs contain their own mean/std normalization."""
from pathlib import Path
import csv
import hashlib
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
MODELS = ("mobilenet_v2", "resnet18", "mobilenet_v3_small")
# Original ImageNet-1k output indices, NOT ImageFolder's contiguous 0..9 labels.
CLASSES = {
    "n01440764": 0, "n02102040": 217, "n02979186": 482,
    "n03000684": 491, "n03028079": 497, "n03394916": 566,
    "n03417042": 569, "n03425413": 571, "n03445777": 574,
    "n03888257": 701,
}

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def rows(split):
    with (ROOT / "data" / f"{split}.csv").open() as f:
        return list(csv.DictReader(f))

def image_input(relative_path):
    # Fixed pilot transform: RGB, resize shortest side to 256 using bilinear,
    # center crop 224, float32 NCHW [0,1]. No extra mean/std normalization.
    with Image.open(ROOT / relative_path) as image:
        image = image.convert("RGB")
        w, h = image.size
        size = (256, int(256 * h / w)) if w <= h else (int(256 * w / h), 256)
        image = image.resize(size, Image.Resampling.BILINEAR)
        left, top = round((size[0] - 224) / 2), round((size[1] - 224) / 2)
        image = image.crop((left, top, left + 224, top + 224))
        return np.ascontiguousarray(np.asarray(image, dtype=np.float32).transpose(2, 0, 1)[None] / 255.0)

def source_model(name):
    return ROOT / "models" / f"{name}-onnx-float" / f"{name}.onnx"

def ort_options():
    import onnxruntime as ort
    options = ort.SessionOptions()
    options.intra_op_num_threads = 4
    options.inter_op_num_threads = 1
    return options
