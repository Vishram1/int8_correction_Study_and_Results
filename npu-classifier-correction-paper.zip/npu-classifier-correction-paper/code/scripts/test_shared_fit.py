"""Check shared objective against independent augmented least squares."""
import unittest
import numpy as np
from shared_common import fit_affine, fit_shared, fold_affine


class SharedFitTests(unittest.TestCase):
    def test_independent_least_squares_with_between_source_shifts(self):
        rng=np.random.default_rng(98)
        x=rng.normal(size=(3,31,7))+np.array([-4,0,7])[:,None,None]
        y=rng.normal(size=(31,7)); ridge=.01
        a,b=fit_shared(x,y,ridge)
        for d in range(7):
            penalty=ridge*np.var(x[:,:,d],axis=1).mean()
            design=np.column_stack([x[:,:,d].ravel(),np.ones(93)])/np.sqrt(93)
            design=np.vstack([design,[np.sqrt(penalty),0]])
            target=np.r_[np.tile(y[:,d],3)/np.sqrt(93),np.sqrt(penalty)]
            expected=np.linalg.lstsq(design,target,rcond=None)[0]
            np.testing.assert_allclose([a[d],b[d]],expected,rtol=2e-6,atol=1e-7)

    def test_single_source_reduction_and_order(self):
        rng=np.random.default_rng(42); x=rng.normal(size=(3,40,6)); y=rng.normal(size=(40,6))
        for one in x:
            for actual,expected in zip(fit_shared(one[None],y),fit_affine(one,y,.01)):
                np.testing.assert_array_equal(actual,expected)
        for actual,expected in zip(fit_shared(x,y),fit_shared(x[::-1],y)):
            np.testing.assert_allclose(actual,expected,atol=1e-7)

    def test_constant_channels_and_invalid_inputs(self):
        a,b=fit_shared(np.full((3,10,2),2.),np.full((10,2),4.))
        np.testing.assert_array_equal(a,[1,1]); np.testing.assert_array_equal(b,[2,2])
        for x,y,r in [(np.empty((0,10,2)),np.ones((10,2)),.01),
                      (np.ones((3,10,2)),np.ones((10,3)),.01),
                      (np.full((3,10,2),np.nan),np.ones((10,2)),.01),
                      (np.ones((3,10,2)),np.ones((10,2)),-1)]:
            with self.assertRaises(ValueError): fit_shared(x,y,r)

    def test_folding_orientation(self):
        rng=np.random.default_rng(91); h=rng.normal(size=(13,6)).astype('f');w=rng.normal(size=(10,6)).astype('f')
        c=rng.normal(size=10).astype('f');a=rng.normal(size=6).astype('f');b=rng.normal(size=6).astype('f')
        wf,cf=fold_affine(w,c,a,b)
        np.testing.assert_allclose(h@wf.T+cf,(h*a+b)@w.T+c,rtol=1e-5,atol=3e-6)


if __name__=='__main__': unittest.main()
