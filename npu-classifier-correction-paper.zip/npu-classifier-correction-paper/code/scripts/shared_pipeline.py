"""Forward-only extension: new calibration caches and closed-form corrections."""
import argparse
import gc
import json
import time
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import onnx
import onnxruntime as ort
from host_experiments import make_sim, calibrate
from shared_common import *

def announce(message):
    print(datetime.now(timezone.utc).isoformat(timespec='seconds'), message, flush=True)


def classifier(model):
    graph = onnx.load(source_model(model))
    node = graph.graph.node[-1]
    if node.op_type != 'Gemm' or len(node.input) != 3:
        raise ValueError('Unsupported classifier; inspect without changing protocol')
    attrs = {a.name: onnx.helper.get_attribute_value(a) for a in node.attribute}
    if attrs.get('transB', 0) != 1 or attrs.get('transA', 0) != 0 or attrs.get('alpha', 1) != 1 or attrs.get('beta', 1) != 1:
        raise ValueError('Unsupported classifier orientation')
    tensors = {t.name: onnx.numpy_helper.to_array(t) for t in graph.graph.initializer}
    w, b = tensors[node.input[1]], tensors[node.input[2]]
    return {'node': node.name, 'feature': node.input[0], 'weight': node.input[1],
            'bias': node.input[2], 'logits': node.output[0], 'dimension': int(w.shape[1])}, w, b


def run_logits(session, data, output=None):
    out = output or session.get_outputs()[0].name
    result = np.empty((len(data), 1000), dtype=np.float32)
    name = session.get_inputs()[0].name
    for i in range(len(data)):
        result[i] = session.run([out], {name: data[i:i+1]})[0][0]
        if (i+1) % 500 == 0:
            announce(f'Logits {i+1}/{len(data)}')
    return result


def add_taps(graph, head):
    node = next(n for n in graph.graph.node if n.name == head['node'])
    taps = {'feature': node.input[0], 'weight': node.input[1], 'bias': node.input[2], 'raw_logits': node.output[0]}
    shapes = {'feature': [1, head['dimension']], 'weight': [1000, head['dimension']], 'bias': [1000], 'raw_logits': [1, 1000]}
    existing = {x.name for x in graph.graph.output}
    for key, name in taps.items():
        if name not in existing:
            graph.graph.output.append(onnx.helper.make_tensor_value_info(name, onnx.TensorProto.FLOAT, shapes[key]))
    return taps


def extract(model, variant):
    out = EXP / model / variant
    if complete(out/'cache-result.json'):
        return
    if not complete(EXP/model/'cal-a/cache-result.json'):
        raise ValueError('Verified original source cache required')
    p = protocol(); head, _, _ = classifier(model); start = time.perf_counter(); costs = {}
    if variant == 'fp32':
        graph = onnx.load(source_model(model))
        original = ort.InferenceSession(graph.SerializeToString(), sess_options=ort_options(), providers=['CPUExecutionProvider'])
        original_logits = run_logits(original, inputs('selection')[:32]); del original
        taps = add_taps(graph, head)
        session = ort.InferenceSession(graph.SerializeToString(), sess_options=ort_options(), providers=['CPUExecutionProvider'])
        sim = None
    else:
        if variant not in p['calibration']['variants']:
            raise ValueError('Unregistered calibration')
        sim = make_sim(model, 8, 'tf_enhanced')
        indices = p['calibration']['variants'][variant]['indices']
        announce(model+' '+variant+' calibrating 500 images')
        stage_start = time.perf_counter()
        calibrate(sim, inputs('calibration')[indices])
        costs['quantizer_calibration_seconds'] = time.perf_counter() - stage_start
        out.mkdir(parents=True, exist_ok=True)
        sim.export(str(out), 'model', encoding_version='1.0.0')
        original_logits = run_logits(sim.session, inputs('selection')[:32])
        taps = add_taps(sim.model.model, head)
        sim._rebuild_session()
        session = sim.session
    out.mkdir(parents=True, exist_ok=True)
    output = session.get_outputs()[0].name
    tapped_logits = run_logits(session, inputs('selection')[:32], output)
    check = comparison(tapped_logits, original_logits)
    if check['max_abs'] > 1e-5 or check['prediction_disagreements']:
        dump(out/'tap-failure.json', check)
        raise ValueError('Exposing features changed classifier outputs')
    in_name = session.get_inputs()[0].name
    names = [output, taps['feature'], taps['raw_logits']]
    files = []
    for split in ('calibration', 'selection'):
        stage_start = time.perf_counter()
        data = inputs(split)
        features = np.empty((len(data), head['dimension']), dtype=np.float32)
        logits = np.empty((len(data), 1000), dtype=np.float32)
        raw_logits = np.empty_like(logits)
        for i in range(len(data)):
            z, h, raw = session.run(names, {in_name: data[i:i+1]})
            logits[i], features[i], raw_logits[i] = z[0], h.reshape(-1), raw[0]
            if (i+1) % 500 == 0:
                announce(f'{model} {variant} {split} features {i+1}/{len(data)}')
        costs[split+'_feature_seconds'] = time.perf_counter() - stage_start
        for name, values in [('features',features), ('logits',logits), ('raw-logits',raw_logits)]:
            if not np.isfinite(values).all():
                raise ValueError('Nonfinite cached features/outputs')
            path = out/(split+'-'+name+'.npy'); np.save(path, values); files.append(path)
    w, b = session.run([taps['weight'], taps['bias']], {in_name: inputs('calibration')[:1]})
    np.savez(out/'head.npz', weight=w, bias=b)
    h = np.load(out/'selection-features.npy')
    raw = np.load(out/'selection-raw-logits.npy')
    head_check = comparison(h @ w.T + b, raw)
    if head_check['max_abs'] > 1e-4:
        raise ValueError('Cached classifier does not reproduce simulated raw logits')
    if variant == 'fp32':
        ref_check = comparison(np.load(out/'selection-logits.npy'), np.load(OLD/'host'/model/'fp32.npy'))
        if ref_check['max_abs'] > 1e-5 or ref_check['prediction_disagreements']:
            raise ValueError('Floating-point teacher differs from saved reference')
    else:
        ref_check = None; files += [out/'model.onnx', out/'model.encodings']
    files.append(out/'head.npz')
    save_result(out/'cache-result.json', {'status':'passed','model':model,'variant':variant,
            'taps':taps,'feature_kind':'dequantized classifier input' if sim is not None else 'FP32 classifier input',
            'tap_identity':check,'cached_head_check':head_check,'fp32_reference_check':ref_check,
            'metrics':metrics(np.load(out/'selection-logits.npy')),'seconds':time.perf_counter()-start,'costs':costs,
            'implementation_sha256':sha256(Path(__file__))}, files)
    announce(model+' '+variant+' cache complete')
    del session,sim;gc.collect()



def fit(model):
    out=EXP/model/'fits'
    if complete(out/'result.json'): return
    out.mkdir(parents=True,exist_ok=True)
    teacher=np.load(EXP/model/'fp32/calibration-features.npy')
    teacher_z=np.load(EXP/model/'fp32/calibration-logits.npy')
    files=[];costs={};params={}
    for name in (*SOURCES,*TARGETS):
        if not complete(EXP/model/name/'cache-result.json'):
            raise ValueError('Cache incomplete: '+name)
        start=time.perf_counter()
        h=np.load(EXP/model/name/'calibration-features.npy')
        a,b=fit_affine(h,teacher,protocol()['fit']['ridge'])
        bias=np.mean(teacher_z.astype(np.float64)-np.load(EXP/model/name/'calibration-raw-logits.npy').astype(np.float64),axis=0).astype(np.float32)
        costs[name]=time.perf_counter()-start
        path=out/(name+'.npz');np.savez(path,a=a,b=b,output_bias=bias);files.append(path);params[name]=(a,b)
    start=time.perf_counter()
    # Explicitly exclude targets from both reused multi-source estimators.
    for label,values in [('average',tuple(np.mean([params[s][j] for s in SOURCES],axis=0,dtype=np.float64).astype(np.float32) for j in (0,1))),
                         ('shared',fit_shared([np.load(EXP/model/s/'calibration-features.npy') for s in SOURCES],teacher,protocol()['fit']['ridge']))]:
        path=out/(label+'.npz');np.savez(path,a=values[0],b=values[1]);files.append(path)
    costs['average_and_shared_seconds']=time.perf_counter()-start
    save_result(out/'result.json',{'model':model,'status':'complete','cost_seconds':costs,
        'shared_sources':list(SOURCES),'primary_single_source':'cal-a','target_data_used_in_reused_fits':False,
        'implementation_sha256':sha256(Path(__file__))},files)
    announce(model+' source/shared/target reference fits complete')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',choices=MODELS,required=True)
    parser.add_argument('--stage',choices=['cache','fit','all'],default='all')
    args=parser.parse_args(); protocol()
    if args.stage in ('cache','all'):
        for name in ('source-c',*TARGETS): extract(args.model,name)
    if args.stage in ('fit','all'): fit(args.model)

if __name__=='__main__':main()
