// Numerical edge checks for external I/O, including A16 paths unsupported by QNN CPU.
#define main runner_program_main
#include "qnn_memory_runner.cpp"
#undef main

int main(int argc,char** argv) {
    require(argc==2,"Pass a scratch input filename");
    uint32_t dims[]={5};float values[]={-1.0f,0.0f,0.5f,1.0f,2.0f};
    {std::ofstream f(argv[1],std::ios::binary);f.write(reinterpret_cast<char*>(values),sizeof(values));}
    for(auto version:{QNN_TENSOR_VERSION_1,QNN_TENSOR_VERSION_2}) {
        for(auto type:{QNN_DATATYPE_UFIXED_POINT_8,QNN_DATATYPE_UFIXED_POINT_16}) {
            Qnn_Tensor_t t=QNN_TENSOR_INIT;t.version=version;
            tensor(t,[&](auto& v){v.rank=1;v.dimensions=dims;v.dataType=type;
                v.quantizeParams.quantizationEncoding=QNN_QUANTIZATION_ENCODING_SCALE_OFFSET;
                v.quantizeParams.scaleOffsetEncoding.scale=1.0f/(type==QNN_DATATYPE_UFIXED_POINT_8?255:65535);
                v.quantizeParams.scaleOffsetEncoding.offset=0;return 0;});
            auto bytes=input(t,argv[1]);auto floats=output(t,bytes);
            require(floats.size()==5 && floats[0]==0 && floats[1]==0 && floats[3]==1 && floats[4]==1,"Saturation/endpoint error");
            require(std::abs(floats[2]-0.5f)<=encoding(t).scale,"Midpoint quantization error");
            bind(t,bytes);
            require(tensor(t,[&](auto& v){return v.clientBuf.data==bytes.data() && v.clientBuf.dataSize==bytes.size();}),"Buffer binding error");
        }
    }
    Qnn_Tensor_t t=QNN_TENSOR_INIT;t.v1.rank=1;t.v1.dimensions=dims;t.v1.dataType=QNN_DATATYPE_FLOAT_32;
    auto floats=output(t,input(t,argv[1]));require(std::memcmp(floats.data(),values,sizeof(values))==0,"FP32 path changed values");
    {std::ofstream f(argv[1],std::ios::binary);f.write(reinterpret_cast<char*>(values),4);}
    bool rejected=false;try{input(t,argv[1]);}catch(const std::exception&){rejected=true;}
    require(rejected,"Truncated input accepted");
    std::cout<<"I/O tests passed: tensor V1/V2, uint8/uint16 saturation and rounding, float32, buffer binding, malformed input\n";
}
