// Original research harness using the public QNN C interfaces.
// No SDK sample implementation is incorporated here.
#include <QnnInterface.h>
#include <System/QnnSystemInterface.h>
#include <HTP/QnnHtpDevice.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <dlfcn.h>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

using Clock = std::chrono::steady_clock;
static double ms(Clock::time_point a, Clock::time_point b) {
    return std::chrono::duration<double, std::milli>(b-a).count();
}
static void check(Qnn_ErrorHandle_t code, const char* action) {
    if (code != QNN_SUCCESS) throw std::runtime_error(std::string(action)+": "+std::to_string(code));
}
static void require(bool ok, const std::string& why) { if (!ok) throw std::runtime_error(why); }
static std::string csv(const char* p) {
    std::string s="\"";
    if(p) for(char c:std::string(p)) { if(c=='"') s+='"'; s+=c; }
    return s+'"';
}
static std::string json(const std::string& s) {
    std::string o="\"";
    for(unsigned char c:s) {
        if(c=='"'||c=='\\') {o+='\\';o+=c;}
        else if(c=='\n')o+="\\n";
        else if(c=='\r')o+="\\r";
        else if(c=='\t')o+="\\t";
        else {require(c>=32,"Unsupported control character");o+=c;}
    }
    return o+'"';
}
template<class Fn> static Fn symbol(void* lib,const char* name) {
    auto p=dlsym(lib,name);require(p!=nullptr,std::string("Missing symbol ")+name);
    return reinterpret_cast<Fn>(p);
}
struct Runtime {
    void *backendLib=nullptr,*systemLib=nullptr;
    QnnInterface_t provider=QNN_INTERFACE_INIT;
    QNN_INTERFACE_VER_TYPE q=QNN_INTERFACE_VER_TYPE_INIT;
    QNN_SYSTEM_INTERFACE_VER_TYPE s=QNN_SYSTEM_INTERFACE_VER_TYPE_INIT;
    Qnn_BackendHandle_t backend=nullptr;
    Qnn_DeviceHandle_t device=nullptr;
    Qnn_ContextHandle_t context=nullptr;
    QnnSystemDlc_Handle_t dlc=nullptr;
    QnnSystemContext_GraphInfo_t* infos=nullptr;
    QnnHtpDevice_PerfInfrastructure_t perf=QNN_HTP_DEVICE_PERF_INFRASTRUCTURE_INIT;
    uint32_t powerId=0;bool powerCreated=false;
    void load(const std::string& back,const std::string& sys) {
        backendLib=dlopen(back.c_str(),RTLD_NOW|RTLD_GLOBAL);
        if(!backendLib)throw std::runtime_error(dlerror());
        systemLib=dlopen(sys.c_str(),RTLD_NOW|RTLD_GLOBAL);
        if(!systemLib)throw std::runtime_error(dlerror());
        const QnnInterface_t** providers=nullptr;uint32_t n=0;
        check(symbol<decltype(&QnnInterface_getProviders)>(backendLib,"QnnInterface_getProviders")(&providers,&n),"backend providers");
        bool found=false;
        for(uint32_t i=0;i<n;++i)if(providers[i]->apiVersion.coreApiVersion.major==QNN_API_VERSION_MAJOR && providers[i]->apiVersion.coreApiVersion.minor>=QNN_API_VERSION_MINOR) {
            provider=*providers[i];q=provider.QNN_INTERFACE_VER_NAME;found=true;break;
        }
        require(found,"No compatible backend interface");
        const QnnSystemInterface_t** systems=nullptr;n=0;
        check(symbol<decltype(&QnnSystemInterface_getProviders)>(systemLib,"QnnSystemInterface_getProviders")(&systems,&n),"system providers");
        found=false;
        for(uint32_t i=0;i<n;++i)if(systems[i]->systemApiVersion.major==QNN_SYSTEM_API_VERSION_MAJOR && systems[i]->systemApiVersion.minor>=QNN_SYSTEM_API_VERSION_MINOR) {
            s=systems[i]->QNN_SYSTEM_INTERFACE_VER_NAME;found=true;break;
        }
        require(found,"No compatible system interface");
        check(q.backendCreate(nullptr,nullptr,&backend),"backendCreate");
    }
    void power() {
        check(q.deviceCreate(nullptr,nullptr,&device),"deviceCreate");
        QnnDevice_Infrastructure_t infra=nullptr;
        check(q.deviceGetInfrastructure(&infra),"deviceGetInfrastructure");
        require(infra && infra->infraType==QNN_HTP_DEVICE_INFRASTRUCTURE_TYPE_PERF,"Missing HTP performance infrastructure");
        perf=infra->perfInfra;
        require(perf.createPowerConfigId && perf.setPowerConfig && perf.destroyPowerConfigId,"Missing performance functions");
        check(perf.createPowerConfigId(0,0,&powerId),"createPowerConfigId");powerCreated=true;
        QnnHtpPerfInfrastructure_PowerConfig_t cfg{};
        cfg.option=QNN_HTP_PERF_INFRASTRUCTURE_POWER_CONFIGOPTION_DCVS_V3;
        auto& v=cfg.dcvsV3Config;
        v.contextId=powerId;v.setDcvsEnable=1;v.dcvsEnable=0;
        v.powerMode=QNN_HTP_PERF_INFRASTRUCTURE_POWERMODE_PERFORMANCE_MODE;
        v.setBusParams=1;v.setCoreParams=1;
        v.busVoltageCornerMin=v.busVoltageCornerTarget=v.busVoltageCornerMax=DCVS_VOLTAGE_VCORNER_TURBO;
        v.coreVoltageCornerMin=v.coreVoltageCornerTarget=v.coreVoltageCornerMax=DCVS_VOLTAGE_VCORNER_TURBO;
        const QnnHtpPerfInfrastructure_PowerConfig_t* configs[]={&cfg,nullptr};
        check(perf.setPowerConfig(powerId,configs),"setPowerConfig");
    }
    ~Runtime() {
        if(context)q.contextFree(context,nullptr);
        if(dlc)s.systemDlcFree(dlc);
        // Metadata is client-owned; this process retains tensor metadata through execution.
        // Nested metadata allocations are reclaimed by process exit.
        if(infos)std::free(infos);
        if(powerCreated)perf.destroyPowerConfigId(powerId);
        if(device)q.deviceFree(device);
        if(backend)q.backendFree(backend);
        if(systemLib)dlclose(systemLib);
        if(backendLib)dlclose(backendLib);
    }
};
template<class F> static auto tensor(Qnn_Tensor_t& t,F f) {
    if(t.version==QNN_TENSOR_VERSION_1)return f(t.v1);
    require(t.version==QNN_TENSOR_VERSION_2,"Unsupported tensor version");return f(t.v2);
}
static size_t elements(Qnn_Tensor_t& t) {
    return tensor(t,[](auto& v){size_t n=1;require(v.rank>0 && v.rank<=8,"Invalid rank");
        for(uint32_t i=0;i<v.rank;++i){require(v.dimensions[i]>0,"Dynamic/zero shape");n*=v.dimensions[i];require(n<=100000000,"Tensor too large");}return n;});
}
static Qnn_DataType_t dtype(Qnn_Tensor_t& t){return tensor(t,[](auto& v){return v.dataType;});}
static unsigned width(Qnn_Tensor_t& t) {
    switch(dtype(t)) {
        case QNN_DATATYPE_FLOAT_32:return 4;
        case QNN_DATATYPE_UFIXED_POINT_8:return 1;
        case QNN_DATATYPE_UFIXED_POINT_16:return 2;
        default:throw std::runtime_error("Unsupported I/O dtype "+std::to_string(dtype(t)));
    }
}
static Qnn_ScaleOffset_t encoding(Qnn_Tensor_t& t) {
    auto qp=tensor(t,[](auto& v){return v.quantizeParams;});
    require(qp.quantizationEncoding==QNN_QUANTIZATION_ENCODING_SCALE_OFFSET,"I/O needs per-tensor scale/offset");
    require(std::isfinite(qp.scaleOffsetEncoding.scale) && qp.scaleOffsetEncoding.scale>0,"Invalid I/O scale");
    return qp.scaleOffsetEncoding;
}
static void bind(Qnn_Tensor_t& t,std::vector<uint8_t>& bytes) {
    tensor(t,[&](auto& v){v.memType=QNN_TENSORMEMTYPE_RAW;v.clientBuf.data=bytes.data();v.clientBuf.dataSize=static_cast<uint32_t>(bytes.size());return 0;});
}
static std::vector<uint8_t> input(Qnn_Tensor_t& t,const std::string& path) {
    size_t n=elements(t);std::vector<float> floats(n);std::ifstream f(path,std::ios::binary|std::ios::ate);
    require(f.good(),"Cannot open input "+path);require(f.tellg()==std::streamoff(n*sizeof(float)),"Input byte count mismatch");
    f.seekg(0);f.read(reinterpret_cast<char*>(floats.data()),n*sizeof(float));require(f.good(),"Input read failed");
    for(float x:floats)require(std::isfinite(x),"Nonfinite input");
    std::vector<uint8_t> raw(n*width(t));
    if(dtype(t)==QNN_DATATYPE_FLOAT_32)std::memcpy(raw.data(),floats.data(),raw.size());
    else {
        auto q=encoding(t);double high=width(t)==1?255:65535;
        for(size_t i=0;i<n;++i){
            // Round half away from zero, then saturate; validated against qnn-net-run.
            uint16_t value=static_cast<uint16_t>(std::clamp(std::round(static_cast<double>(floats[i])/q.scale)-q.offset,0.0,high));
            if(width(t)==1)raw[i]=static_cast<uint8_t>(value);else std::memcpy(raw.data()+2*i,&value,2);
        }
    }
    return raw;
}
static std::vector<float> output(Qnn_Tensor_t& t,const std::vector<uint8_t>& raw) {
    std::vector<float> out(elements(t));
    if(dtype(t)==QNN_DATATYPE_FLOAT_32)std::memcpy(out.data(),raw.data(),raw.size());
    else {
        auto q=encoding(t);
        for(size_t i=0;i<out.size();++i){uint16_t v=raw[i];if(width(t)==2)std::memcpy(&v,raw.data()+2*i,2);out[i]=(static_cast<int32_t>(v)+q.offset)*q.scale;}
    }
    for(float x:out)require(std::isfinite(x),"Nonfinite output");
    return out;
}
struct Event {int call,depth;uint32_t type,unit;std::string value,name;};
static void events(Runtime& r,QnnProfile_EventId_t id,int call,int depth,std::vector<Event>& out) {
    require(depth<32,"Profile nesting too deep");QnnProfile_EventData_t e=QNN_PROFILE_EVENT_DATA_INIT;
    auto code=r.q.profileGetEventData(id,&e);
    if(code==QNN_PROFILE_ERROR_INCOMPATIBLE_EVENT) {
        QnnProfile_ExtendedEventData_t ext=QNN_PROFILE_EXTENDED_EVENT_DATA_INIT;
        check(r.q.profileGetExtendedEventData(id,&ext),"profileGetExtendedEventData");
        require(ext.version==QNN_PROFILE_DATA_VERSION_1,"Unsupported extended event version");
        auto& v=ext.v1;std::ostringstream value;value<<std::setprecision(17);
        if(v.unit!=QNN_PROFILE_EVENTUNIT_OBJECT) {
            switch(v.value.dataType) {
                case QNN_DATATYPE_UINT_64:value<<v.value.uint64Value;break;
                case QNN_DATATYPE_UINT_32:value<<v.value.uint32Value;break;
                case QNN_DATATYPE_INT_64:value<<v.value.int64Value;break;
                case QNN_DATATYPE_INT_32:value<<v.value.int32Value;break;
                case QNN_DATATYPE_FLOAT_32:value<<v.value.floatValue;break;
                case QNN_DATATYPE_FLOAT_64:value<<v.value.doubleValue;break;
                default:throw std::runtime_error("Unsupported profile scalar type "+std::to_string(v.value.dataType));
            }
        }
        out.push_back({call,depth,v.type,v.unit,value.str(),v.identifier?v.identifier:""});
    } else {
        check(code,"profileGetEventData");out.push_back({call,depth,e.type,e.unit,std::to_string(e.value),e.identifier?e.identifier:""});
    }
    const QnnProfile_EventId_t* subs=nullptr;uint32_t n=0;
    check(r.q.profileGetSubEvents(id,&subs,&n),"profileGetSubEvents");
    for(uint32_t i=0;i<n;++i)events(r,subs[i],call,depth+1,out);
}
int main(int argc,char** argv) {
    try {
        std::map<std::string,std::string> a;
        if(argc==2 && std::string(argv[1])=="--help") {
            std::cout<<"--backend PATH --system PATH --dlc PATH --inputs LIST --out DIR --profile off|basic --perf default|htp-turbo --warmup N --calls N --save-logits 0|1\n";return 0;
        }
        require(argc%2==1,"Every option needs a value");
        for(int i=1;i<argc;i+=2){require(!a.count(argv[i]),"Duplicate argument");a[argv[i]]=argv[i+1];}
        const std::vector<std::string> names={"--backend","--system","--dlc","--inputs","--out","--profile","--perf","--warmup","--calls","--save-logits"};
        for(auto& n:names)require(a.count(n),"Missing "+n);
        require(a.size()==names.size(),"Unknown option");
        require(a["--profile"]=="off"||a["--profile"]=="basic","Invalid profile");
        require(a["--perf"]=="default"||a["--perf"]=="htp-turbo","Invalid perf");
        require(a["--save-logits"]=="0"||a["--save-logits"]=="1","Invalid save flag");
        int warmup=std::stoi(a["--warmup"]),calls=std::stoi(a["--calls"]);
        require(warmup>=0 && warmup<=10000 && calls>0 && calls<=10000,"Invalid call count");
        bool basic=a["--profile"]=="basic",save=a["--save-logits"]=="1";
        require(!std::filesystem::exists(a["--out"]+"/complete.json"),"Refusing to overwrite completed run");
        std::filesystem::create_directories(a["--out"]);
        auto start=Clock::now();Runtime r;r.load(a["--backend"],a["--system"]);
        if(a["--perf"]=="htp-turbo")r.power();
        check(r.q.contextCreate(r.backend,r.device,nullptr,&r.context),"contextCreate");
        check(r.s.systemDlcCreateFromFile(nullptr,a["--dlc"].c_str(),&r.dlc),"systemDlcCreateFromFile");
        uint32_t ng=0;
        check(r.s.systemDlcComposeGraphs(r.dlc,nullptr,0,r.backend,r.context,r.provider,QNN_SYSTEM_CONTEXT_GRAPH_INFO_VERSION_1,&r.infos,&ng),"systemDlcComposeGraphs");
        require(ng==1 && r.infos[0].version==QNN_SYSTEM_CONTEXT_GRAPH_INFO_VERSION_1,"Expected one graph");
        auto& g=r.infos[0].graphInfoV1;
        require(g.numGraphInputs==1 && g.numGraphOutputs==1,"Expected one input/output");
        Qnn_GraphHandle_t graph=nullptr;check(r.q.graphRetrieve(r.context,g.graphName,&graph),"graphRetrieve");
        auto composed=Clock::now();check(r.q.graphFinalize(graph,nullptr,nullptr),"graphFinalize");auto finalized=Clock::now();
        Qnn_Tensor_t in=g.graphInputs[0],out=g.graphOutputs[0];
        require(elements(in)==224*224*3 && elements(out)==1000,"Unexpected I/O element counts");
        tensor(in,[](auto& v){require(v.rank==4 && v.dimensions[0]==1 && v.dimensions[1]==224 && v.dimensions[2]==224 && v.dimensions[3]==3,"Expected NHWC batch1 input");return 0;});
        std::ifstream list(a["--inputs"]);require(list.good(),"Cannot open input list");
        std::vector<std::string> paths;std::vector<std::vector<uint8_t>> inputs;std::string line;
        while(std::getline(list,line)) {if(!line.empty()&&line.back()=='\r')line.pop_back();if(line.empty())continue;
            require(paths.size()<100,"Input pool capped at 100; use accuracy chunks");paths.push_back(line);inputs.push_back(input(in,line));}
        require(!inputs.empty(),"Empty input list");
        std::vector<uint8_t> rawOutput(elements(out)*width(out));bind(out,rawOutput);
        std::vector<double> times(warmup+calls);std::vector<Event> traces;traces.reserve((warmup+calls)*32);
        std::vector<float> logits(save?calls*1000:0);auto loaded=Clock::now();
        for(int i=0;i<warmup+calls;++i){
            // Pointer selection, profile creation, output conversion and all I/O are outside timing.
            size_t ix=(i<warmup?i:i-warmup)%inputs.size();bind(in,inputs[ix]);
            Qnn_ProfileHandle_t profile=nullptr;
            if(basic)check(r.q.profileCreate(r.backend,QNN_PROFILE_LEVEL_BASIC,&profile),"profileCreate");
            auto t0=Clock::now();auto code=r.q.graphExecute(graph,&in,1,&out,1,profile,nullptr);auto t1=Clock::now();
            times[i]=ms(t0,t1);check(code,"graphExecute");
            if(basic){
                const QnnProfile_EventId_t* ids=nullptr;uint32_t n=0;check(r.q.profileGetEvents(profile,&ids,&n),"profileGetEvents");
                for(uint32_t j=0;j<n;++j)events(r,ids[j],i,0,traces);
                check(r.q.profileFree(profile),"profileFree");
            }
            if(save && i>=warmup){auto values=output(out,rawOutput);std::copy(values.begin(),values.end(),logits.begin()+(i-warmup)*1000);}
        }
        auto finished=Clock::now();
        std::ofstream timing(a["--out"]+"/timings.csv");timing<<"call,phase,input_index,elapsed_ms\n"<<std::setprecision(12);
        for(int i=0;i<warmup+calls;++i)timing<<i<<','<<(i<warmup?"warmup":"measured")<<','<<(i<warmup?i:i-warmup)%inputs.size()<<','<<times[i]<<'\n';
        timing.close();require(timing.good(),"Timing write failed");
        std::ofstream profile(a["--out"]+"/events.csv");profile<<"call,depth,type,unit,value,identifier\n";
        for(auto& e:traces)profile<<e.call<<','<<e.depth<<','<<e.type<<','<<e.unit<<','<<e.value<<','<<csv(e.name.c_str())<<'\n';
        profile.close();require(profile.good(),"Profile write failed");
        if(save){std::ofstream f(a["--out"]+"/logits.f32",std::ios::binary);f.write(reinterpret_cast<char*>(logits.data()),logits.size()*4);f.close();require(f.good(),"Logits write failed");}
        const char* build=nullptr;check(r.q.backendGetBuildId(&build),"backendGetBuildId");
        std::ofstream meta(a["--out"]+"/complete.json");
        meta<<std::setprecision(12)<<"{\n\"schema\":1,\"runner\":\"qnn-memory-v1\",\"backend_build\":"<<json(build?build:"")
            <<",\"backend_path\":"<<json(a["--backend"])<<",\"dlc\":"<<json(a["--dlc"])
            <<",\"profile\":"<<json(a["--profile"])<<",\"perf_request\":"<<json(a["--perf"])
            <<",\"perf_api_accepted\":"<<(r.powerCreated?"true":"false")<<",\"warmup\":"<<warmup<<",\"calls\":"<<calls
            <<",\"input_pool\":"<<inputs.size()<<",\"input_dtype\":"<<dtype(in)<<",\"output_dtype\":"<<dtype(out)
            <<",\"compose_setup_ms\":"<<ms(start,composed)<<",\"finalize_ms\":"<<ms(composed,finalized)
            <<",\"input_preparation_ms\":"<<ms(finalized,loaded)<<",\"loop_wall_ms\":"<<ms(loaded,finished)
            <<",\"clock\":\"steady_clock\",\"timing_scope\":\"synchronous graphExecute with raw client buffers; internal runtime copies included\""
            <<",\"profile_extraction\":\"fresh handle per call, extraction outside interval; intercall perturbation reported via off/basic comparison\""
            <<",\"saved_logits\":"<<(save?"true":"false")<<"}\n";
        meta.close();require(meta.good(),"Metadata write failed");
        std::cout<<"Completed "<<calls<<" measured calls and "<<warmup<<" warm-up calls\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<"RUNNER_ERROR: "<<e.what()<<'\n';return 1;}
}
