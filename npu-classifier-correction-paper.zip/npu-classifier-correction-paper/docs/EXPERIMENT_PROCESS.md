# Exact process for the shared-correction extension

This study extends the completed recalibration pilot without modifying its paper, raw returns, or archived evidence. The new study lives in `experiments/recalibration-shared-20261014-v1`. Its question is whether a fixed small classifier correction retains accuracy across previously unseen INT8 calibrations, and whether fitting over several calibrations helps enough to justify the extra preparation.

## Frozen design

`protocol.json` and `protocol.sha256` were written before new calibration inference. The same pretrained MobileNetV2 and ResNet18 graphs, original model weights, ImageNetV2 split, preprocessing, AIMET 2.40.0, and QAIRT 2.45.41.260507 are used. Inputs are RGB, resized on the shorter side to 256, center-cropped to 224, and converted to float32 NCHW in [0,1]. The downloaded source graphs include normalization; it is not applied a second time. Native inputs contain the identical values in NHWC order.

| Role | Calibration name | Seed | Native panel? |
|---|---|---:|---|
| Existing source | cal-a | 2026100601 | Source only |
| Existing source | cal-b | 2026100602 | Source only |
| New source | source-c | 2026101401 | Source only |
| New target | target-1 | 2026101411 | Yes |
| New target | target-2 | 2026101412 | Yes |
| New target | target-3 | 2026101413 | No |
| New target | target-4 | 2026101414 | No |
| New target | target-5 | 2026101415 | No |

Each draw samples 500 images without replacement from the original 1,000-image calibration/adaptation pool using NumPy `default_rng(seed).choice`. The sorted indices and full overlap matrix are in the protocol. Draws overlap and share one underlying dataset. They are not independent datasets. Existing A/B outcomes were known when planning the extension; the five target draws were new. Source A is the prespecified ordinary-reuse baseline.

All correction fits use the same 1,000 adaptation images. The 2,000 development images are used for implementation checks and descriptive diagnostics, with no hyperparameter or arm selection. The other 7,000 images are reserved for one final evaluation after artifact freezing and successful native validation. Reading or copying their identity manifest does not run inference on them.

## Extraction and fitting

1. Verify the prior experiment's source, data, and cache hashes. Copy the FP32 teacher and source A/B caches into the new namespace with links to their original records. Original files remain unchanged.
2. For source C and each target, create an AIMET simulation with `param_type='int8'`, `activation_type='int8'`, `quant_scheme='tf_enhanced'`, and `config_file='htp_v81'`. Compute encodings on that draw's 500 images. Save its unmodified baseline and encodings.
3. Expose the *actual dequantized classifier input* and effective quantized classifier weight/bias. Check that adding these outputs preserves predictions and that the cached features reproduce the classifier's raw logits. Cache adaptation and development features. These are forward passes, not full-network training.
4. Independently fit one affine transform per feature channel from quantized features to the frozen FP32 teacher features. Use float64 statistics, ridge 0.01, and float32 stored parameters. Labels are not used in fitting.

For one source with features x and teacher y, minimize

`mean_i (a*x_i + b - y_i)^2 + 0.01*Var_i(x)*(a-1)^2`.

The intercept is unpenalized. For variance greater than 1e-12,

`a = (Cov(x,y) + 0.01*Var(x)) / (1.01*Var(x)); b = mean(y) - a*mean(x)`.

For a constant channel, use `a=1` and align its mean with `b`. The averaging arm takes the arithmetic mean of the three independently fitted `a` vectors and the three `b` vectors.

The shared arm minimizes the mean of the three source reconstruction objectives plus `0.01*mean_c Var_i(x[c,i])*(a-1)^2`. It uses one shared intercept and slope per channel. Therefore,

`a = (pooled_covariance + 0.01*mean_within_variance) / (pooled_variance + 0.01*mean_within_variance)`.

Using pooled variance *in the penalty* would define a different objective. An independent augmented least-squares test checks the implemented expression. The single-source reduction, constant-channel handling, and folding orientation are also tested.

With the same teacher for all sources, standard algebra expresses the shared slope as a variance-weighted combination of source slopes, with shrinkage from differences between source feature means. `feature-diagnostics.json` measures this relationship and target feature reconstruction errors. This is an explanation of established least squares, not a novel theorem; feature error is not classification accuracy.

## Seven arms and export

Each of the five targets per model receives all seven arms: unchanged baseline; no-learning head re-encoding; source-A affine reuse; parameter average; shared affine; target-refitted affine; and target-refitted output bias. The target-refitted references deliberately receive target adaptation features. The reused fits never use target features. All transformed heads still require the target's 500 examples for head re-encoding.

Let target classifier output be `W*h+c`, where W/c are the cached *effective quantized* target head. Fold the feature correction with

`W_new = W * a[None,:]`, and `c_new = c + W @ b`.

For the bias reference, add `mean(teacher_logits - target_raw_logits)` to the effective bias. The no-learning re-encoding control materializes the same effective W/c without a learned correction. The unchanged baseline keeps the original tensors and encodings.

Load the target encodings strictly and freeze all upstream quantizers. Only the classifier weight, bias, and final-output quantizers may change. During AIMET head calibration, restore frozen quantizers to quantize/dequantize mode so the global statistics context cannot change the backbone. Calibrate the head using the target's original 500-image subset. Compare sliced-head predictions against full-graph execution and audit all parameter/encoding changes.

The fixed native panel comprises target-1 and target-2 for both architectures: 28 artifacts. Convert the ONNX graphs and overrides with `qairt-converter`, requesting NHWC input; quantize with 8-bit weights/activations, 32-bit bias, and per-channel weights. Audit the actual resulting tensor types. Requested W8A8 does not imply every intermediate/bias uses eight bits. Compare each native graph with its target baseline; only classifier weight/bias/output tensors may differ.

## Validation and final evaluation

`artifact-freeze.json` binds all 70 host artifacts, 28 native artifacts, caches, fitted parameters, source code, and runtime files. `execution-identity.json` binds the DLCs and Android runtime independently of the input package. This lets the final package contain different images while requiring the exact validated models/runtime.

The validation ZIP contains only the first 10 existing development inputs. Each artifact runs three jobs: Qualcomm's reference runner, the memory runner without profiling, and the memory runner with basic profiling. All 10 output vectors must be bitwise identical; 12 HTP execute events must be present for the profiled job, including two warmups. The Linux analyzer checks job coverage, DLC hashes, backend build, outputs, profile events, device identity, and raw evidence. A passing Windows message alone does not open final evaluation.

Validation records are saved in each return and under a unique trial name. The final builder accepts any complete matching Linux-audited validation; it has no hardcoded dependency on an older validation trial. The final launcher checks the same handset serial/build. Temperatures are recorded with Android thermal management enabled. There is no 40 C starting gate. These runs are accuracy acquisitions, not latency benchmarks.

After validation, `build_shared_bundle.py --mode Final --validation ...` prepares the final inputs and native package. `shared_final.py` evaluates the frozen host matrix without fitting or recalibrating. The native package has 70 chunks of 100 images for each of 28 artifacts, in a fixed randomized order: 1,960 jobs / 196,000 scored image executions. Checkpoints allow technical resumption without tuning. Final outputs must not be used to select a new method, seed, ridge, or favorable subset.

## Analysis and limits

Primary contrasts are shared minus source-A reuse and shared minus target refit. Report all seven arms, every target, the equal-target mean, and the worst observed target contrast. Analyze architectures and host/native backends separately. Final uncertainty uses 10,000 paired class-cluster bootstrap samples, retaining the same image/class draws across arms and calibrations. The 95% intervals are pointwise and conditional on the observed targets; repeated images are not independent calibration experiments.

The prospective 0.5 percentage-point loss budget corresponds to 35/7,000 predictions. It is a working descriptive engineering criterion, not a user-validated application requirement. No formal population noninferiority claim is planned.

Count preparation honestly. Shared/average fitting requires three source feature sets; ordinary reuse requires one. Every transformed target head needs 500 target features for mandatory re-encoding. Target-refitting additionally uses the other 500 adaptation images. The comparison pipeline extracts all 1,000 target features because it must construct all arms; this is not work avoided by that pipeline. Separately report calibration, feature extraction, fitting, head export, and conversion stages. A/B cache times are historical and not a controlled speed comparison. No inference-latency or energy benefit is inferred from preparation times or parameter counts.

Affine correction, shared fitting, and averaging are established. The candidate contribution is a bounded, reproducible answer about correction transfer across new digital quantizer realizations and what survives actual NPU deployment. Five overlapping host targets and two native targets per model do not establish broad calibration or hardware robustness.
