# Revision 2 — clearer contribution and practical use

This revision changes the presentation and interpretation of the same completed study. It does not change any predictions, labels, fitted parameters, statistical analysis, tables, or figure values. The preceding manuscript and its release archives remain preserved.

The central question and frozen primary comparisons remain shared-minus-single and shared-minus-target-refit. The revision emphasizes the practical meaning of the already specified descriptive loss budget and the demonstrated deployment workflow. It does not convert that budget into a formal noninferiority claim or select a new primary endpoint after evaluation.

## Supported findings emphasized

- Both Single and Shared met the preset 0.5-percentage-point **observed** accuracy-loss budget relative to target refitting on every tested host/native target. The worst observed native loss was 0.071 pp for each method, equivalent to five additional mistakes on one 7,000-image target evaluation.
- Across the ten host model–target cases, the worst observed losses were 0.343 pp for Single and 0.229 pp for Shared. These finite-panel extrema do not establish superior worst-case robustness for Shared.
- Both corrections fold into the target classifier without adding graph operators. This is an implementation property shared by the methods, not a measured latency or energy benefit.
- Reuse requires no target-specific correction fit, but still requires the target's 500 calibration examples for head re-encoding. The comparative experiment collected all 1,000 target adaptation features to construct all controls and did not measure this work being avoided.

## Findings that remain equally visible

- Native Shared minus Single is +0.043 pp for MobileNetV2 and −0.107 pp for ResNet18, with the original conditional confidence intervals shown in the abstract and results.
- Shared has no consistently demonstrated advantage over Single, Average, Refit, or the unchanged target in this study.
- All 98 accuracy entries, 126 contrast intervals, output ties, controls, and target outcomes are unchanged. The preset bootstrap, fitting objective, data partitions, and native coverage are unchanged.
- Source overlap, previously consulted development data, the limited hardware panel, missing detailed setup notes, and conditional rather than population inference remain disclosed.

The added practical guidance explains how others can use the released folding/re-encoding/validation workflow and its controls. It is identified as guidance from these observations, not a newly validated selection algorithm.

The revision provides no fabricated or selectively altered result and makes no new superiority, speed, power, or energy claim. Nothing has been submitted or published.
