# Reproduction scope

## Verify the reported results

From the repository root, with Python 3.10:

```bash
python -m pip install -r requirements.txt
python verify_evidence.py
```

The unchanged independent verifier checks the original evidence inventory, exact label ordering, all 98 host/native accuracy cells and 126 paired-bootstrap intervals. It also reconstructs both FP32 references. The calculation uses 10,000 class-bootstrap resamples with seed 2026101499. The same seven images per class stay paired across methods and targets. The two/five target calibrations are held fixed; these intervals do not characterize the population of all possible calibrations.

`evidence/predictions.npz` includes predicted class indices and counts of equal maximum scores. Its arrays are ordered as `[model, target, arm, image]`; FP32 references are `[model, image]`. The order is explicit in `evidence/provenance.json`. The original first-index `argmax` tie rule is unchanged.

The compact predictions suffice to reproduce the paper's accuracy/tie statistics. They cannot reconstruct full logit vectors, rerun an NPU or independently authenticate the original phone acquisition. Full-output hashes and the sanitized acquisition summary document that boundary.

## Regenerate tables and figures without editing released evidence

```bash
python -m pip install -r requirements-render.txt
python scripts/reproduce.py --render
```

The wrapper verifies the root evidence, saves newly reconstructed statistics under `build/reproduced/`, and stages the manuscript and rendering script there. It compares every regenerated table and result CSV with the released values. Original `main.pdf`, evidence, figures and their hashes remain untouched.

The output directory must be new. To repeat the process, choose another output directory:

```bash
python scripts/reproduce.py --render --output build/reproduced-again
```

With TeX Live/latexmk or Tectonic available, build the staged source:

```bash
bash build/reproduced/manuscript/build.sh
```

All bibliography entries, the generated `.bbl`, tables and figures are included. The paper does not rely on an unpublished remote style file. Statistical verification is Python-only; the optional shell-based PDF build assumes Linux, macOS or a suitable Windows Unix shell/WSL environment.

## Rerunning model inference

The paper's deployed models were prepared with AIMET 2.40.0, ONNX 1.19.0, ONNX Runtime 1.23.2 and QAIRT 2.45.41.260507. The original Python environment snapshots are under `environment/`; the host and QAIRT environments are separate because their dependencies differ. They document the original environments and are not required for compact statistical verification.

External assets and recorded archive hashes are listed in `environment/external-assets.json`:

1. ImageNetV2 MatchedFrequency, pinned Hugging Face revision `d626240be2538720e83103a0e1178d24aca8b12c`. Use the exact rows in `evidence/calibration.csv`, `selection.csv` and `final.csv`; preprocessing is specified in `EXPERIMENT_PROCESS.md` and `code/scripts/pilot_common.py`.
2. MobileNetV2 and ResNet18 float ONNX bundles from AI Hub model release v0.63.0. MobileNetV2 uses the vendored tonylins model family; substituting torchvision's default MobileNetV2 checkpoint changes the experiment. Model file hashes are also frozen in `evidence/protocol.json`.
3. QAIRT 2.45.41.260507 from Qualcomm, installed under its terms, plus Android NDK r26d for compiling the provided C++ runner.
4. A compatible SM8850 Android device, connected to the execution machine with ADB, for any new native acquisition.

The upstream model metadata records the tools used to create those downloaded model packages. Those upstream versions differ from the QAIRT version used by this experiment; do not substitute one for the other.

The archived scripts under `code/scripts/` expect workspace-relative `code/data/`, `code/models/`, `code/tools/` and dated `code/experiments/` directories. In particular, the shared study reused FP32 and source-A/B caches from the earlier recalibration pilot. Its sealed artifact checks also reference the original runtime manifest and completed validation. Those large caches, binaries and private raw returns are not in this Git folder. Full hardware replay therefore needs restoration or deliberate rebuilding of those prerequisites; there is no claim that running the archived final-stage script alone recreates the complete original workspace.

For a new run, follow the stage order in [EXPERIMENT_PROCESS.md](EXPERIMENT_PROCESS.md): data/model verification, calibration/cache extraction, correction fitting, folding and head re-encoding, DLC audit, native validation, artifact freeze, final inference and paired analysis. Assign a new run identifier and preserve its true device/build/setup records. The old 7,000 images were a held-out test for the original study, but they are now public evaluated evidence and cannot serve as a new untouched test for tuning another method.

## Contents intentionally kept outside Git

| External material | Included replacement/reference |
|---|---|
| Dataset image pixels | Exact split identities, labels, hashes and source URL |
| Pretrained and compiled model binaries | Original model metadata, archive/file hashes, correction parameters and conversion code |
| QAIRT/NDK/runtime binaries | Versions, acquisition references and original runner source |
| Full logits and original phone files | Complete compact predictions/tie counts, full-output hashes and labeled public audit derivative |
| Local environments, caches and credentials | Dependency specifications; none of the local environment directories |

The preserved paper reports accuracy and preparation-stage records. Its acquisitions are not controlled latency or energy benchmarks. Device continuity with older pilot handsets is unconfirmed; the matching validation/final identity and measurement limitations are retained in `evidence/audit-public.json`.
